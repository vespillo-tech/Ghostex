#!/usr/bin/env python3
"""One-off reproduction using an isolated zmx directory and public pixels."""
import errno
import fcntl
import json
import os
from pathlib import Path
import pty
import select
import struct
import subprocess
import sys
import tempfile
import termios
import time

ZMX = Path(os.environ["GX_IMAGE_ZMX"])
TAG = os.environ.get("GX_IMAGE_TAG", "zmx")
PNG = os.environ.get("GX_IMAGE_PNG", "")
ENV = os.environ.copy()
for key in ("ZMX_SESSION", "ZMX_SESSION_PREFIX"):
    ENV.pop(key, None)
ENV["ZMX_DIR"] = tempfile.mkdtemp(prefix="gx-image-replay-", dir="/private/tmp")
ENV["TERM"] = "xterm-ghostty"
SESSION = "image-fixture"
MARKER = b"IMAGE-FIXTURE-READY"
PRODUCER = r'''
import sys, time
time.sleep(0.5)
out = sys.stdout.buffer
out.write(b'\x1b[2J\x1b[H\x1b_Ga=T,f=32,i=52,s=2,v=2,c=2,r=2,C=1,q=2;/wAA/wD/AP8AAP///////w==\x1b\\')
out.write(b'\x1b[38;2;0;0;52m\xf4\x8e\xbb\xae\xcc\x85\xcc\x85\xf4\x8e\xbb\xae\x1b[0m\r\nIMAGE-FIXTURE-READY')
out.flush()
time.sleep(120)
'''

if PNG:
    from base64 import b64encode
    payload = b64encode(Path(PNG).read_bytes()).decode()
    PRODUCER = PRODUCER.replace("f=32,i=52,s=2,v=2", "f=100,i=52")
    PRODUCER = PRODUCER.replace("/wAA/wD/AP8AAP///////w==", payload)

CASE = os.environ.get("GX_IMAGE_CASE", "")
if CASE:
    import base64
    def image(image_id, green=False):
        pixels = bytes([0,255,0,255] if green else [255,0,0,255])*4
        cmd = f"\x1b_Ga=T,f=32,i={image_id},p=7,s=2,v=2,c=2,r=2,U=1,C=1,q=2;".encode()+base64.b64encode(pixels)+b"\x1b\\"
        text = f"\x1b[38;2;0;0;{image_id}m\x1b[58;2;0;0;7m\U0010eeee\u0305\u0305\U0010eeee\x1b[0m".encode()
        return cmd+text
    output = b"\x1b[2J\x1b[H"+image(52)
    if CASE == "alternate":
        output += b"\x1b[?1049h"+image(53, True)
    elif CASE == "delete":
        output += b"\x1b_Ga=d,d=I,i=52,q=2\x1b\\"
    elif CASE == "replace":
        output += b"\x1b[H"+image(52, True)
    elif CASE == "scrollback":
        output += b"\r\n"*30
    elif CASE.startswith("placements-"):
        count = int(CASE.split("-", 1)[1])
        for placement in range(8, 8 + count - 1):
            output += f"\x1b_Ga=p,U=1,i=52,p={placement},c=2,r=2,q=2\x1b\\".encode()
    else:
        raise ValueError(CASE)
    output += b"\r\nIMAGE-FIXTURE-READY"
    PRODUCER = "import sys,time;sys.stdout.buffer.write("+repr(output)+");sys.stdout.buffer.flush();time.sleep(120)"

def attach(create=False):
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 24, 80, 640, 384))
    args = [str(ZMX), "attach"]
    if not create:
        args.append("--require-existing")
    args.append(SESSION)
    if create:
        args.extend([sys.executable, "-c", PRODUCER])
    proc = subprocess.Popen(args, env=ENV, stdin=slave, stdout=slave,
                            stderr=slave, start_new_session=True)
    os.close(slave)
    return proc, master

def capture(master, timeout=4):
    data = bytearray()
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not select.select([master], [], [], 0.2)[0]:
            if MARKER in data:
                break
            continue
        try:
            chunk = os.read(master, 65536)
        except OSError as exc:
            if exc.errno == errno.EIO:
                break
            raise
        if not chunk:
            break
        data.extend(chunk)
    return bytes(data)

def detach(proc, master):
    if proc.poll() is None:
        os.write(master, b"\x1c")
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.terminate()
            proc.wait(timeout=3)
    os.close(master)

clients = []
try:
    first = attach(create=True)
    clients.append(first)
    live = capture(first[1])
    if MARKER not in live or b"\x1b_G" not in live:
        raise RuntimeError(f"live fixture did not arrive: {live!r}")
    os.write(first[1], b"\x1b]1337;ZMX_REFRESH\x07")
    refresh = capture(first[1])
    if MARKER not in refresh:
        raise RuntimeError(f"refresh did not arrive: {refresh!r}")
    detach(*clients.pop())
    second = attach()
    clients.append(second)
    reattach = capture(second[1])
    if MARKER not in reattach:
        raise RuntimeError(f"reattach did not restore the fixture: {reattach!r}")
    result = {
        "socket_directory": ENV["ZMX_DIR"],
        "live": {"bytes": len(live), "graphics_commands": live.count(b"\x1b_G")},
        "refresh": {"bytes": len(refresh), "graphics_commands": refresh.count(b"\x1b_G")},
        "reattach": {"bytes": len(reattach), "graphics_commands": reattach.count(b"\x1b_G")},
        "refresh_placeholder": b"\xf4\x8e\xbb\xae" in refresh,
        "reattach_placeholder": b"\xf4\x8e\xbb\xae" in reattach,
    }
    for name, data in (("live", live), ("refresh", refresh), ("reattach", reattach)):
        Path(__file__).with_name(f"{TAG}-{name}.vt").write_bytes(data)
    print(json.dumps(result, indent=2))
finally:
    for client in clients:
        detach(*client)
    subprocess.run([str(ZMX), "kill", SESSION], env=ENV, capture_output=True, timeout=5)
    listed = subprocess.run([str(ZMX), "list", "--short"], env=ENV,
                            capture_output=True, timeout=5)
    if listed.stdout.strip():
        raise RuntimeError("isolated fixture session was not cleaned up")
