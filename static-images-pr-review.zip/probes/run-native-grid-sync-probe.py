#!/usr/bin/env python3
"""Exercise the actual native reader against disposable local zmx sessions."""
from pathlib import Path
import fcntl,os,pty,select,stat,struct,subprocess,sys,tempfile,termios,time
folder=Path(__file__).resolve().parent
zmx=Path(os.environ["GX_IMAGE_ZMX"])
probe=Path(os.environ["GX_IMAGE_NATIVE_PROBE"])
image=b'\x1b_Ga=T,f=32,i=52,p=3,s=1,v=1,c=2,r=2,C=1,q=2;/wAA/w==\x1b\\'
payload=b'0123456789'*80+b'\r\nANCHOR'+image+b'\r\ntail\x1b]2;FIXTURE_READY\x07'
for sync in ('legacy','sync'):
 for kind in (('quiet','append','overwrite','pixels') if sync=='sync' else ('quiet','append','overwrite')):
  env=os.environ.copy()
  for key in ('ZMX_SESSION','ZMX_SESSION_PREFIX','GHOSTEX_ZMX_GRID_NONCE'):env.pop(key,None)
  directory=tempfile.mkdtemp(prefix='gx-native-grid-',dir='/private/tmp');env['ZMX_DIR']=directory
  master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',24,200,1600,384))
  producer='import sys,time;time.sleep(.4);sys.stdout.buffer.write('+repr(payload)+');sys.stdout.buffer.flush();time.sleep(120)'
  creator=subprocess.Popen([str(zmx),'attach','grid-fixture',sys.executable,'-c',producer],env=env,stdin=slave,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
  try:
   data=bytearray();end=time.monotonic()+4
   while b'FIXTURE_READY' not in data:
    assert time.monotonic()<end,'producer timed out'
    if select.select([master],[],[],.1)[0]:data.extend(os.read(master,65536))
   os.write(master,b'\x1c');creator.wait(timeout=4);os.close(master);master=None
   sockets=[p for p in Path(directory).iterdir() if stat.S_ISSOCK(p.stat().st_mode)]
   assert len(sockets)==1
   run=subprocess.run([str(probe),str(zmx),'grid-fixture',directory,str(sockets[0]),kind,sync],env=env,capture_output=True,text=True,timeout=20)
   print(run.stdout,end='',flush=True)
   if run.returncode:print(run.stderr,file=sys.stderr);raise RuntimeError('native probe failed')
  finally:
   if creator.poll() is None:creator.terminate();creator.wait(timeout=3)
   if master is not None:os.close(master)
   subprocess.run([str(zmx),'kill','grid-fixture'],env=env,capture_output=True,timeout=5)
   left=subprocess.run([str(zmx),'list','--short'],env=env,capture_output=True,timeout=5)
   assert not left.stdout.strip(),'fixture cleanup failed'
print('PASS six native reflow cases plus same-grid pixel change; all disposable sessions closed')
