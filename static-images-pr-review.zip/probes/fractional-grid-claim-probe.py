#!/usr/bin/env python3
"""Reproduce no-op claims with pixel totals not divisible by their grid."""
from pathlib import Path
import fcntl,os,pty,select,socket,stat,struct,subprocess,sys,tempfile,termios,time
zmx=Path(os.environ["GX_IMAGE_ZMX"])
env=os.environ.copy()
for key in ('ZMX_SESSION','ZMX_SESSION_PREFIX','GHOSTEX_ZMX_GRID_NONCE'):env.pop(key,None)
env['ZMX_DIR']=tempfile.mkdtemp(prefix='gx-fractional-grid-',dir='/private/tmp')
m,s=pty.openpty();fcntl.ioctl(s,termios.TIOCSWINSZ,struct.pack('HHHH',24,80,640,384))
proc=subprocess.Popen([str(zmx),'attach','fractional-fixture',sys.executable,'-c',"import time;time.sleep(.3);print('PROBE_READY',flush=True);time.sleep(30)"],env=env,stdin=s,stdout=s,stderr=s,start_new_session=True);os.close(s)
conn=None
def send(tag,payload=b''):conn.sendall(struct.pack('<BI',tag,len(payload))+b'\0'*3+payload)
def exact(n):
 data=bytearray()
 while len(data)<n:
  b=conn.recv(n-len(data));assert b;data.extend(b)
 return bytes(data)
def barrier():
 send(6);messages=[]
 while True:
  header=exact(8);tag=header[0];payload=exact(struct.unpack('<I',header[1:5])[0])
  if tag==6:return messages
  messages.append((tag,payload))
try:
 data=bytearray();end=time.monotonic()+4
 while b'PROBE_READY' not in data:
  assert time.monotonic()<end
  if select.select([m],[],[],.1)[0]:data.extend(os.read(m,65536))
 path=next(p for p in Path(env['ZMX_DIR']).iterdir() if stat.S_ISSOCK(p.stat().st_mode))
 conn=socket.socket(socket.AF_UNIX);conn.settimeout(3);conn.connect(str(path))
 resize=struct.pack('<HHHH',24,80,641,385);send(210);send(7,resize);barrier()
 for i in range(3):
  send(207,b'\0'+resize);messages=barrier()
  outputs=sum(tag==1 for tag,_ in messages);grids=sum(tag==210 for tag,_ in messages)
  print(f'CLAIM {i+1}: full-refresh-messages={outputs}, grid-records={grids}',flush=True)
  if '--expect-clean' in sys.argv:assert outputs==0 and grids==0
finally:
 if conn:conn.close()
 if proc.poll() is None:proc.terminate();proc.wait(timeout=3)
 os.close(m);subprocess.run([str(zmx),'kill','fractional-fixture'],env=env,capture_output=True,timeout=5)
 assert not subprocess.run([str(zmx),'list','--short'],env=env,capture_output=True,timeout=5).stdout.strip()
