#!/usr/bin/env python3
"""Compile the one-off probe using a built renderer's actual modules and libraries."""
import argparse,json,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('renderer',type=Path)
p.add_argument('target',type=Path,help='Cargo target directory with release dependencies')
p.add_argument('--ghostty-lib-dir',required=True,type=Path)
p.add_argument('--rust-version',default='1.95.0')
p.add_argument('--extern',action='append',required=True,help='NAME=/absolute/path/to/matching.rlib; repeat for portable_pty, anyhow, libc, image')
a=p.parse_args();renderer=a.renderer.resolve();target=a.target.resolve();lib=a.ghostty_lib_dir.resolve()
assert (lib/'libghostty-vt.a').is_file()
deps=target/'release/deps';source=Path(__file__).with_name('native-grid-sync-probe.rs').read_text()
# Public package uses a token; local source retains the original explicit path.
for name in ('ghostty_vt/mod.rs','terminal_environment.rs','terminal_model.rs'):
 import re
 pattern=r'#\[path = "[^"]*/apps/desktop/src/'+re.escape(name)+r'"\]'
 source,n=re.subn(pattern,'#[path = '+json.dumps(str(renderer/'apps/desktop/src'/name))+']',source)
 assert n==1,name
root=Path(tempfile.mkdtemp(prefix='gx-native-probe-'));rs=root/'probe.rs';rs.write_text(source)
command=['rustc','+'+a.rust_version,'--edition=2024','-O',str(rs),'-o',str(root/'native-grid-sync-probe'),'-L','dependency='+str(deps)]
externs=dict(value.split('=',1) for value in a.extern)
assert set(externs)=={'portable_pty','anyhow','libc','image'}
for name,path in externs.items():
 path=Path(path).resolve();assert path.is_file(),path
 command.extend(['--extern',name+'='+str(path)])
command.extend(['-L','native='+str(lib),'-lstatic=ghostty-vt','-lc++'])
subprocess.run(command,check=True)
print(root/'native-grid-sync-probe')
