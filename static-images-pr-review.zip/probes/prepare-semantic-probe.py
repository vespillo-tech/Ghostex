#!/usr/bin/env python3
"""Prepare the verified replay harness in a sibling copy; do not build or launch."""
import argparse
from pathlib import Path
import shutil
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('source', type=Path, help='zmx checkout with the candidate applied')
args = parser.parse_args()
source = args.source.resolve()
root = Path(tempfile.mkdtemp(prefix='gx-static-image-probe-', dir=source.parent))
shutil.copytree(source / 'src', root / 'src')
for name in ('build.zig', 'build.zig.zon'):
    shutil.copy2(source / name, root / name)
snippet = Path(__file__).with_name('semantic-replay-probe.zig').read_text()
util = root / 'src/util.zig'
assert 'runImageReplayProbe' not in util.read_text()
util.write_text(util.read_text() + '\n' + snippet)
(root / 'src/probe.zig').write_text(
    'const std=@import("std"); pub fn main(init:std.process.Init) !void '
    '{try @import("util.zig").runImageReplayProbe(init.gpa,init.io);}\n')
build = root / 'build.zig'
build.write_text(build.read_text().replace('src/main.zig', 'src/probe.zig', 1))
print(root)
