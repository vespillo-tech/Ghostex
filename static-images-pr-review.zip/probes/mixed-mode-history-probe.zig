fn firstHistoryCells(alloc:std.mem.Allocator,t:*ghostty_vt.Terminal) ![]u8 {
 const pin=t.screens.active.pages.getTopLeft(.screen);const page=pin.node.page();const row=pin.rowAndCell().row;
 var w:std.Io.Writer.Allocating=.init(alloc);defer w.deinit();
 for(page.getCells(row),0..) |*cell,x| {try w.writer.print("{d}:{x}/{any}/{any};",.{x,cell.codepoint(),cell.wide,page.lookupGrapheme(cell)});}
 return alloc.dupe(u8,w.writer.buffered());
}

pub fn runMixedModeProbe(alloc:std.mem.Allocator,io:std.Io) !void {
 var src=try testCreateTerminal(alloc,io,10,6,"");defer src.deinit(alloc);
 var input=src.vtStream();defer input.deinit();
 input.nextSlice("\x1b[?2027h👨‍👩X\r\n\r\n\r\n\r\n\r\n\r\n\x1b[?2027lNOW");
 const replay=serializeTerminalState(alloc,&src) orelse return error.NoSnapshot;defer alloc.free(replay);
 var dst=try testCreateTerminal(alloc,io,10,6,"");defer dst.deinit(alloc);
 var output=dst.vtStream();defer output.deinit();output.nextSlice(replay);
 const a=try retainedText(alloc,src.screens.active);defer alloc.free(a);const b=try retainedText(alloc,dst.screens.active);defer alloc.free(b);
 const ca=try firstHistoryCells(alloc,&src);defer alloc.free(ca);const cb=try firstHistoryCells(alloc,&dst);defer alloc.free(cb);
 std.debug.print("MIXED MODE history-cell match={any}\nSOURCE CELLS {s}\nREPLAY CELLS {s}\n",.{std.mem.eql(u8,ca,cb),ca,cb});
 std.debug.print("MIXED MODE history retained-text match={any}\nSOURCE {s}\nREPLAY {s}\n",.{std.mem.eql(u8,a,b),a,b});
}
