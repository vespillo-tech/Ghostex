#![allow(dead_code, unused_imports)]
#[path = "__GHOSTEX_RENDERER_ROOT__/apps/desktop/src/ghostty_vt/mod.rs"] mod ghostty_vt;
#[path = "__GHOSTEX_RENDERER_ROOT__/apps/desktop/src/terminal_environment.rs"] mod terminal_environment;
#[path = "__GHOSTEX_RENDERER_ROOT__/apps/desktop/src/terminal_model.rs"] mod terminal_model;
use terminal_model::*;
use std::{sync::Arc, time::{Duration,Instant}, io::{Read,Write}, os::unix::net::UnixStream};
fn emit(socket: &str, bytes: &[u8]) -> std::io::Result<()> {
 let mut conn=UnixStream::connect(socket)?;let mut header=vec![1u8];header.extend_from_slice(&(bytes.len() as u32).to_le_bytes());header.extend_from_slice(&[0;3]);conn.write_all(&header)?;conn.write_all(bytes)?;
 conn.write_all(&[6,0,0,0,0,0,0,0])?;conn.set_read_timeout(Some(Duration::from_secs(3)))?;
 loop{let mut h=[0u8;8];conn.read_exact(&mut h)?;let n=u32::from_le_bytes(h[1..5].try_into().unwrap()) as usize;let mut body=vec![0u8;n];conn.read_exact(&mut body)?;if h[0]==6 {break;}}
 Ok(())
}
fn spawn(zmx:&str,session:&str,directory:&str,cols:u16,sync:bool)->anyhow::Result<TerminalModel> {
 let env=vec![("ZMX_DIR".into(),directory.into()),("GHOSTEX_ZMX_GRID_SYNC".into(),if sync {"1"}else{"0"}.into())];
 TerminalModel::spawn(TerminalSpawnConfig {program:zmx.into(),args:vec!["attach".into(),"--require-existing".into(),session.into()],env,cwd:None,cols,rows:24,cell_width_px:8,cell_height_px:16,max_scrollback:1_000_000},Arc::new(|_|{}))
}
fn wait(model:&mut TerminalModel,predicate:impl Fn(&TerminalSnapshot)->bool)->TerminalSnapshot {
 let until=Instant::now()+Duration::from_secs(4);
 loop{let frame=model.snapshot().unwrap();if predicate(&frame){return frame;}assert!(Instant::now()<until,"snapshot wait timed out: cols={} images={} title={:?} exit={:?} text={:?}",frame.cols,frame.images.len(),model.title(),model.exit_status(),frame.rows.iter().map(|r|r.text()).collect::<Vec<_>>());std::thread::sleep(Duration::from_millis(10));}
}
fn main()->anyhow::Result<()> {
 let args:Vec<_>=std::env::args().collect();let (zmx,session,directory,socket,kind,sync)=(&args[1],&args[2],&args[3],&args[4],&args[5],args[6]=="sync");
 let mut model=spawn(zmx,session,directory,200,sync)?;
 let _first=wait(&mut model,|f|f.images.len()==1);
 model.write_input(zmx_client_visible_sequence(24,200).as_bytes())?;
 emit(socket,b"\x1b]2;CLAIM_BARRIER\x07")?;
 let deadline=Instant::now()+Duration::from_secs(3);while model.title().as_deref()!=Some("CLAIM_BARRIER"){assert!(Instant::now()<deadline);std::thread::sleep(Duration::from_millis(10));}
 // The daemon continues at200 until the ordered claim. The synced replica
 // must stay there too while receiving old-grid output, despite slot resize.
 if kind=="pixels" {
  let before=model.snapshot()?.images[0].clone();
  model.resize(200,24,16,32)?;
  model.write_input(zmx_client_visible_sequence(24,200).as_bytes())?;
  let after=wait(&mut model,|f|f.cell_size_px==(16,32)&&f.images.len()==1);
  assert_eq!((after.images[0].col,after.images[0].row),(before.col,before.row));
  assert_eq!(after.images[0].width,before.width*2);assert_eq!(after.images[0].height,before.height*2);
  println!("PASS native same-grid pixel change:200x24,8x16->16x32, stable anchor and doubled geometry");
  model.kill()?;return Ok(());
 }
 model.resize(80,24,8,16)?;
 let pending=model.snapshot()?;assert_eq!(pending.cols,if sync {200}else{80});
 let mut bytes=Vec::new();
 if kind!="quiet" {bytes.extend_from_slice(if kind=="overwrite" {b"\x1b[1;1H"}else{b"\r\n"});bytes.extend_from_slice(&b"abcdefghij".repeat(120));}
 bytes.extend_from_slice(b"\x1b]2;OLD_GRID_READY\x07");emit(socket,&bytes)?;
 let deadline=Instant::now()+Duration::from_secs(3);while model.title().as_deref()!=Some("OLD_GRID_READY"){assert!(Instant::now()<deadline);std::thread::sleep(Duration::from_millis(10));}
 model.write_input(zmx_client_visible_sequence(24,80).as_bytes())?;
 let actual=wait(&mut model,|f|f.cols==80&&f.images.len()==1);
 // A new same-grid attachment supplies independent authoritative replay.
 let mut fresh=spawn(zmx,session,directory,80,true)?;
 let expected=wait(&mut fresh,|f|f.cols==80&&f.images.len()==1);
 let a=&actual.images[0];let b=&expected.images[0];
 let geometry=(a.col,a.row,a.width,a.height)==(b.col,b.row,b.width,b.height);
 let text:Vec<_>=actual.rows.iter().map(|row|row.text()).collect();let expected_text:Vec<_>=expected.rows.iter().map(|row|row.text()).collect();
 println!("NATIVE sync={sync} {kind}: viewer=({},{}), daemon=({},{}), geometry={geometry}, text={}",a.col,a.row,b.col,b.row,text==expected_text);
 if sync{assert!(geometry);assert_eq!(a.image.rgba,b.image.rgba);assert_eq!(text,expected_text);}
 if !sync&&kind=="overwrite"{assert!(!geometry,"unfenced control should reproduce drift");}
 model.kill()?;fresh.kill()?;Ok(())
}
