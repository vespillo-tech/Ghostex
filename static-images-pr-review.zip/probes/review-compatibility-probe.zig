// External validation only; no repository test changes.
pub fn runReviewCompatibilityProbe(alloc:std.mem.Allocator,io:std.Io) !void {
    const img="\x1b_Ga=T,f=32,i=52,p=3,s=1,v=1,c=2,r=2,C=1,q=2;/wAA/w==\x1b\\";
    for([_]bool{false,true}) |redraw| {
        var src=try testCreateTerminal(alloc,io,200,24,"");defer src.deinit(alloc);src.width_px=1600;src.height_px=384;
        var dst=try testCreateTerminal(alloc,io,200,24,"");defer dst.deinit(alloc);dst.width_px=1600;dst.height_px=384;
        src.flags.shell_redraws_prompt=.false;dst.flags.shell_redraws_prompt=.false;
        var a=src.vtStream();defer a.deinit();var b=dst.vtStream();defer b.deinit();
        const osc=if(redraw) "\x1b]133;A;redraw=1\x07" else "\x1b]133;A;redraw=0\x07";
        a.nextSlice(osc);b.nextSlice(osc);
        for(0..80) |_| {a.nextSlice("0123456789");b.nextSlice("0123456789");}
        a.nextSlice("ANCHOR"++img++"tail");b.nextSlice("ANCHOR"++img++"tail");
        const saved=src.flags.shell_redraws_prompt;src.flags.shell_redraws_prompt=.false;
        try src.resize(alloc,.{.cols=80,.rows=24});src.flags.shell_redraws_prompt=saved;
        try dst.resize(alloc,.{.cols=80,.rows=24});
        const before_a=try parkedAnchor(&src);const before_b=try parkedAnchor(&dst);
        const text_a=try retainedText(alloc,src.screens.active);defer alloc.free(text_a);
        const text_b=try retainedText(alloc,dst.screens.active);defer alloc.free(text_b);
        std.debug.print("PROMPT redraw={any}: before-refresh text={any} image=({d},{d})/({d},{d})\n",.{redraw,std.mem.eql(u8,text_a,text_b),before_a.row,before_a.col,before_b.row,before_b.col});
        const refresh=serializeVisibleTerminalState(alloc,&src) orelse return error.NoSnapshot;defer alloc.free(refresh);b.nextSlice(refresh);
        try expectScreensMatch(alloc,&src,&dst);
        const after_a=try parkedAnchor(&src);const after_b=try parkedAnchor(&dst);
        std.debug.print("PROMPT redraw={any}: after-refresh image-match={any}\n",.{redraw,after_a.row==after_b.row and after_a.col==after_b.col});
        try testing.expectEqual(after_a.row,after_b.row);try testing.expectEqual(after_a.col,after_b.col);
    }
    for([_]bool{false,true}) |open| {
        var src=try testCreateTerminal(alloc,io,20,6,"");defer src.deinit(alloc);
        var dst=try testCreateTerminal(alloc,io,20,6,"");defer dst.deinit(alloc);
        src.modes.set(.synchronized_output,open);dst.modes.set(.synchronized_output,open);
        const refresh=serializeVisibleTerminalState(alloc,&src) orelse return error.NoSnapshot;defer alloc.free(refresh);
        var s=dst.vtStream();defer s.deinit();s.nextSlice(refresh);
        try testing.expectEqual(open,src.modes.get(.synchronized_output));try testing.expectEqual(open,dst.modes.get(.synchronized_output));
        std.debug.print("PASS refresh preserves program synchronized-output={any}\n",.{open});
    }
}
