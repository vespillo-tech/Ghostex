// External semantic probe, appended only to our disposable harness copy.
fn parkedAnchor(term: *ghostty_vt.Terminal) !struct { row: i64, col: u16 } {
    const screen=term.screens.active;
    const top=screen.pages.pointFromPin(.screen,screen.pages.getTopLeft(.active)).?.screen.y;
    var entries=screen.kitty_images.placements.iterator();
    const entry=entries.next() orelse return error.MissingImage;
    const point=screen.pages.pointFromPin(.screen,entry.value_ptr.location.pin.*).?.screen;
    return .{.row=@as(i64,point.y)-top,.col=point.x};
}
pub fn runParkedReflowProbe(alloc: std.mem.Allocator, io: std.Io) !void {
    const image="\x1b_Ga=T,f=32,i=52,p=3,s=1,v=1,c=2,r=2,C=1,q=2;/wAA/w==\x1b\\";
    for ([_]bool{false,true}) |fenced| {
    for ([_][]const u8{"quiet","append during resize","overwrite during resize"}) |name| {
        var src=try testCreateTerminal(alloc,io,200,24,"");defer src.deinit(alloc);
        src.width_px=1600;src.height_px=384;
        var input=src.vtStream();defer input.deinit();
        for(0..80) |_| input.nextSlice("0123456789");
        input.nextSlice("\r\nANCHOR"++image++"\r\ntail");
        const attach=serializeTerminalState(alloc,&src) orelse return error.NoSnapshot;defer alloc.free(attach);
        var dst=try testCreateTerminal(alloc,io,200,24,"");defer dst.deinit(alloc);
        dst.width_px=1600;dst.height_px=384;
        var output=dst.vtStream();defer output.deinit();output.nextSlice(attach);
        if(!fenced){try dst.resize(alloc,.{.cols=80,.rows=24});dst.width_px=640;}
        if(!std.mem.eql(u8,name,"quiet")) {
            const prefix=if(std.mem.startsWith(u8,name,"overwrite")) "\x1b[1;1H" else "\r\n";
            input.nextSlice(prefix);output.nextSlice(prefix);
            for(0..120) |_| {input.nextSlice("abcdefghij");output.nextSlice("abcdefghij");}
        }
        try src.resize(alloc,.{.cols=80,.rows=24});src.width_px=640;
        if(fenced){try dst.resize(alloc,.{.cols=80,.rows=24});dst.width_px=640;}
        const a_before=try parkedAnchor(&src);const b_before=try parkedAnchor(&dst);
        std.debug.print("BEFORE REFRESH fence={any} {s}: daemon row={d} col={d}, client row={d} col={d}, match={any}\n",.{fenced,name,a_before.row,a_before.col,b_before.row,b_before.col,a_before.row==b_before.row and a_before.col==b_before.col});
        const refresh=serializeVisibleTerminalState(alloc,&src) orelse return error.NoSnapshot;defer alloc.free(refresh);
        try testing.expect(std.mem.indexOf(u8,refresh,"\x1b_G")==null);
        output.nextSlice(refresh);
        try expectScreensMatch(alloc,&src,&dst);
        const a=try parkedAnchor(&src);const b=try parkedAnchor(&dst);
        std.debug.print("REFLOW fence={any} {s}: daemon row={d} col={d}, client row={d} col={d}, match={any}\n",.{fenced,name,a.row,a.col,b.row,b.col,a.row==b.row and a.col==b.col});
        if(fenced) {try testing.expectEqual(a.row,b.row);try testing.expectEqual(a.col,b.col);}
    }
    }
}
