#!/usr/bin/env python3
"""Disposable PTY checks: token scope, empty Init and old-daemon fallback."""
from pathlib import Path
import fcntl,os,pty,re,select,stat,struct,subprocess,sys,tempfile,termios,time
root=Path(__file__).resolve().parents[2]
new=Path(os.environ["GX_IMAGE_ZMX"])
old=Path(os.environ["GX_IMAGE_OLD_ZMX"])
nonce='0123456789abcdef0123456789abcdef'
record=re.compile(rb'\x1b_ZMX_GRID;'+nonce.encode()+rb';([0-9a-f]{16})\x1b\\')
def read_until(master,predicate,timeout=4):
 data=bytearray();end=time.monotonic()+timeout
 while not predicate(bytes(data)):
  assert time.monotonic()<end,repr(bytes(data))
  if select.select([master],[],[],.1)[0]:data.extend(os.read(master,65536))
 return bytes(data)
def start(binary,env,code,ordered):
 m,s=pty.openpty();fcntl.ioctl(s,termios.TIOCSWINSZ,struct.pack('HHHH',24,80,640,384))
 e=env.copy()
 if ordered:e['GHOSTEX_ZMX_GRID_NONCE']=nonce
 proc=subprocess.Popen([str(binary),'attach','compat-fixture',sys.executable,'-c',code],env=e,stdin=s,stdout=s,stderr=s,start_new_session=True);os.close(s)
 return proc,m
def detach(proc,m):
 os.write(m,b'\x1c')
 try:proc.wait(timeout=2)
 except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=3)
 os.close(m)
for case in ('scope','empty','old'):
 env=os.environ.copy()
 for key in ('ZMX_SESSION','ZMX_SESSION_PREFIX','GHOSTEX_ZMX_GRID_NONCE','GHOSTEX_ZMX_GRID_SYNC'):env.pop(key,None)
 env['ZMX_DIR']=tempfile.mkdtemp(prefix='gx-grid-compat-',dir='/private/tmp')
 env['ZMX_TRACK_ENV']='GHOSTEX_ZMX_GRID_NONCE,GHOSTEX_ZMX_GRID_SYNC'
 procs=[];masters=[]
 try:
  if case=='scope':
   code="import os,sys,time;time.sleep(.3);print('NONCE_ABSENT='+str('GHOSTEX_ZMX_GRID_NONCE' not in os.environ),flush=True);time.sleep(30)"
   proc,m=start(new,env,code,True);procs.append(proc);masters.append(m)
   data=read_until(m,lambda b:b'NONCE_ABSENT=True' in b)
   assert any(r!=b'0'*16 for r in record.findall(data)), 'missing baseline'
   tracked=subprocess.run([str(new),'print-env','compat-fixture'],env=env,capture_output=True,check=True).stdout
   assert b'GRID_NONCE' not in tracked and b'GRID_SYNC' not in tracked
   print('PASS token absent from session program and tracked environment; new-daemon creation',flush=True)
  elif case=='empty':
   proc,m=start(new,env,'import time;time.sleep(30)',True);procs.append(proc);masters.append(m)
   data=read_until(m,lambda b:any(r!=b'0'*16 for r in record.findall(b)))
   assert b'0018005002800180' in record.findall(data)
   print('PASS output-less Init carries authoritative 80x24 grid and pixel metrics',flush=True)
  else:
   creator,cm=start(old,env,"import time;time.sleep(.3);print('OLD_READY',flush=True);time.sleep(30)",False)
   procs.append(creator);masters.append(cm);read_until(cm,lambda b:b'OLD_READY' in b);detach(creator,cm);masters.pop();procs.pop()
   proc,m=start(new,env,'unused',True);procs.append(proc);masters.append(m)
   data=read_until(m,lambda b:b'OLD_READY' in b)
   assert record.findall(data)==[b'0'*16], record.findall(data)
   print('PASS new ordered attach to old daemon receives reset and ordinary text replay; no false authoritative grid',flush=True)
 finally:
  for proc,m in zip(procs,masters):
   if proc.poll() is None:detach(proc,m)
   else:os.close(m)
  subprocess.run([str(new),'kill','compat-fixture'],env=env,capture_output=True,timeout=5)
  left=subprocess.run([str(new),'list','--short'],env=env,capture_output=True,timeout=5)
  assert not left.stdout.strip()
print('PASS all compatibility fixtures closed')
