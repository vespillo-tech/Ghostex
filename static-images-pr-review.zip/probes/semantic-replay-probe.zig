fn imageState(alloc: std.mem.Allocator, screen: *const ghostty_vt.Screen) ![]u8 {
    var lines: std.ArrayList([]u8) = .empty;
    defer { for (lines.items) |line| alloc.free(line); lines.deinit(alloc); }
    var it=screen.kitty_images.placements.iterator();
    while (it.next()) |kv| {
        const p=kv.value_ptr.*;
        var row:i64=-1; var col:u32=0; var wrapped=false;
        if (p.location==.pin) { const pt=screen.pages.pointFromPin(.screen,p.location.pin.*).?; row=pt.screen.y; col=pt.screen.x; wrapped=p.location.pin.rowAndCell().row.wrap; }
        const id: u32=if(kv.key_ptr.placement_id.tag==.external) kv.key_ptr.placement_id.id else 0;
        try lines.append(alloc,try std.fmt.allocPrint(alloc,"{d}/{d}/{d}/{d}/{d}/{d}/{d}/{d}/{d}/{d}/{d}/{d}/{d}/{any}",.{kv.key_ptr.image_id,id,row,col,p.columns,p.rows,p.source_x,p.source_y,p.source_width,p.source_height,p.x_offset,p.y_offset,p.z,wrapped}));
    }
    std.mem.sort([]u8,lines.items,{},struct{fn lt(_:void,a:[]u8,b:[]u8)bool{return std.mem.order(u8,a,b)==.lt;}}.lt);
    return std.mem.join(alloc,"\n",lines.items);
}
fn retainedText(alloc: std.mem.Allocator, screen: *const ghostty_vt.Screen) ![]u8 {
    var writer: std.Io.Writer.Allocating=.init(alloc);defer writer.deinit();
    var fmt=ghostty_vt.formatter.ScreenFormatter.init(screen,.plain);
    fmt.content=.{.selection=ghostty_vt.Selection.init(screen.pages.getTopLeft(.screen),screen.pages.getBottomRight(.active).?,false)};
    try fmt.format(&writer.writer);return alloc.dupe(u8,writer.writer.buffered());
}
fn checkImageState(alloc: std.mem.Allocator, src: *ghostty_vt.Terminal, dst: *ghostty_vt.Terminal) !void {
    for ([_]ghostty_vt.ScreenSet.Key{.primary,.alternate}) |key| {
        const a=src.screens.get(key) orelse continue; const b=dst.screens.get(key) orelse { if(key==.alternate and src.screens.active_key==.primary) continue; return error.MissingScreen; };
        const at=try retainedText(alloc,a);defer alloc.free(at);const bt=try retainedText(alloc,b);defer alloc.free(bt);try testing.expectEqualStrings(at,bt);
        const aa=try imageState(alloc,a);defer alloc.free(aa);const bb=try imageState(alloc,b);defer alloc.free(bb);
        try testing.expectEqualStrings(aa,bb);
        try testing.expectEqual(a.kitty_images.images.count(),b.kitty_images.images.count());
        var it=a.kitty_images.images.iterator();
        while(it.next()) |kv| {const image=b.kitty_images.images.get(kv.key_ptr.*) orelse return error.MissingImage;try testing.expectEqualSlices(u8,kv.value_ptr.data.bytes().?,image.data.bytes().?);}
    }
    try testing.expectEqual(src.screens.active.cursor.x,dst.screens.active.cursor.x);
    try testing.expectEqual(src.screens.active.cursor.y,dst.screens.active.cursor.y);
    try testing.expectEqual(src.screens.active.cursor.pending_wrap,dst.screens.active.cursor.pending_wrap);
    try testing.expectEqual(src.modes.get(.origin),dst.modes.get(.origin));
    try testing.expectEqual(src.modes.get(.grapheme_cluster),dst.modes.get(.grapheme_cluster));
    try expectScreensMatch(alloc,src,dst);
}
pub fn runImageReplayProbe(alloc:std.mem.Allocator,io:std.Io) !void {
    const img="\x1b_Ga=T,f=32,i=52,p=3,s=2,v=2,c=4,r=2,X=1,Y=2,z=-1,C=1,q=2;/wAA/wD/AP8AAP///////w==\x1b\\";
    const raw="\x1b_Ga=t,f=32,i=52,s=2,v=2,q=2;/wAA/wD/AP8AAP///////w==\x1b\\";
    const history="\x1b[6;1H\r\nH0\r\nH1\r\nH2\r\nH3\r\nH4\r\nH5\r\nH6\r\nH7";
    const cases=[_]struct{name:[]const u8,bytes:[]const u8}{
        .{.name="ordinary",.bytes="\x1b[3;4H"++img++"\x1b[5;2Hcursor"},
        .{.name="mixed",.bytes=raw++"\x1b[3;4H\x1b_Ga=p,i=52,p=3,c=4,r=2,C=1,q=2\x1b\\\x1b_Ga=p,i=52,p=7,U=1,c=4,r=2,q=2\x1b\\"},
        .{.name="internal",.bytes=raw++"\x1b[3;4H\x1b_Ga=p,i=52,c=4,r=2,C=1,q=2\x1b\\\x1b[2;1H\x1b_Ga=p,i=52,c=4,r=2,C=1,q=2\x1b\\"},
        .{.name="unplaced",.bytes=raw},
        .{.name="blank history anchor",.bytes="\x1b[2;4H"++img++history},
        .{.name="styled history anchor",.bytes="\x1b[2;1H\x1b[31mtext\x1b[0m"++img++history},
        .{.name="wrapped history anchor",.bytes="\x1b[2;1Habcdefghijklmnopqrst"++img++"B"++history},
        .{.name="spacer head history anchor",.bytes="1234567890123456789中tail\x1b[1;1H"++img++history},
        .{.name="spacer head erased history anchor",.bytes="1234567890123456789中tail\x1b[2;1H\x1b[2K\x1b[1;1H"++img++history},
        .{.name="last softwrap history anchor",.bytes="1234567890123456789中tail\x1b[1;1H"++img++"\x1b[6;1H\r\nx"},
        .{.name="sparse spacer head history anchor",.bytes="abc\x1b[1;20H中tail\x1b[1;1H"++img++history},
        .{.name="sparse erased spacer history anchor",.bytes="abc\x1b[1;20H中tail\x1b[2;1H\x1b[2K\x1b[1;1H"++img++history},
        .{.name="sparse last history anchor",.bytes="abc\x1b[1;20H中tail\x1b[1;1H"++img++"\x1b[6;1H\r\nx"},
        .{.name="unanchored erased continuation",.bytes=raw++"\x1b[2;1HabcdefghijklmnopqrstB\x1b[3;1H\x1b[2K\x1b[4;1Hx\x1b[5;1H\x1b_Ga=p,i=52,p=4,c=2,r=2,C=1,q=2\x1b\\"++history},
        .{.name="text only boundary spacer",.bytes="\x1b[6;1H1234567890123456789中tail\r\n\r\n\r\n\r\n\r\n"},
        .{.name="text only boundary wrap",.bytes="\x1b[6;1HabcdefghijklmnopqrstB\r\n\r\n\r\n\r\n\r\n"},
        .{.name="viewport image boundary spacer",.bytes="\x1b[6;1H1234567890123456789中tail\r\n\r\n\r\n\r\n\r\n\x1b[3;4H"++img},
        .{.name="text only grapheme",.bytes="\x1b[?2027h👨‍👩X"},
        .{.name="wide tail history anchor",.bytes="123456789012345678中tail\x1b[1;1H"++img++history},
        .{.name="space history anchor",.bytes="1234567890123456789 tail\x1b[1;1H"++img++history},
        .{.name="grapheme viewport",.bytes="\x1b[?2027h👨‍👩X\x1b[3;4H"++img},
        .{.name="grapheme history",.bytes="\x1b[?2027h👨‍👩X\x1b[1;1H"++img++history},
        .{.name="both screens grapheme",.bytes="\x1b[?2027h👨‍👩X\x1b[3;4H"++img++"\x1b[?1049h👨‍👩X\x1b[4;3H"++img},
        .{.name="grapheme off",.bytes="\x1b[?2027l👨‍👩X\x1b[3;4H"++img},
        .{.name="wide history anchor",.bytes="\x1b[2;5H界\x1b[2;6H"++img++history},
        .{.name="straddling history",.bytes="\x1b_Ga=T,f=32,i=52,p=3,s=2,v=2,c=4,r=8,C=1,q=2;/wAA/wD/AP8AAP///////w==\x1b\\\x1b[6;1H\r\nH0\r\nH1\r\nH2"},
        .{.name="pending wrap",.bytes="\x1b[3;4H"++img++"\x1b[1;1Habcdefghijklmnopqrst"},
        .{.name="origin margins",.bytes="\x1b[3;4H"++img++"\x1b[2;5r\x1b[?6h\x1b[2;2H"},
        .{.name="blank soft-wrap continuation",.bytes="\x1b[2;1Habcdefghijklmnopqrst"++img++"B\x1b[3;1H\x1b[2K\x1b[4;1Hx\x1b[5;1H\x1b_Ga=p,i=52,p=4,c=2,r=2,C=1,q=2\x1b\\"++history},
        .{.name="short lines reflow",.bytes="hi\r\nhi\r\n"++img++history},
        .{.name="origin pending wrap",.bytes="\x1b[3;4H"++img++"\x1b[2;5r\x1b[?6h\x1b[2;1Habcdefghijklmnopqrst"},
        .{.name="horizontal origin margins",.bytes="\x1b[3;4H"++img++"\x1b[?69h\x1b[3;18s\x1b[2;5r\x1b[?6h\x1b[2;2H"},
        .{.name="origin restored outside margins",.bytes="\x1b[3;4H"++img++"\x1b[?6h\x1b7\x1b[5;6r\x1b8"},
        .{.name="pending edge space",.bytes="\x1b[3;4H"++img++"\x1b[1;1Habcdefghijklmnopqrs "},
        .{.name="both screens pending space",.bytes="\x1b[3;4H"++img++"\x1b[1;1Habcdefghijklmnopqrs \x1b[?1049h\x1b[4;3H"++img},
        .{.name="pending restored outside horizontal margins",.bytes="\x1b[3;4H"++img++"\x1b[?69h\x1b[1;18s\x1b[1;1Habcdefghijklmnopq \x1b7\x1b[1;10s\x1b8"},
        .{.name="both screens horizontal pending",.bytes="\x1b[3;4H"++img++"\x1b[?69h\x1b[1;18s\x1b[1;1Habcdefghijklmnopq \x1b[?1049h\x1b[1;20s\x1b[4;3H"++img},
        .{.name="both screens origin",.bytes="\x1b[2;5r\x1b[?6h\x1b[2;4H"++img++"\x1b[?1049h\x1b[?6l\x1b[r\x1b[4;3H"++img},
        .{.name="both screens",.bytes="\x1b[3;4H"++img++"\x1b[?1049h\x1b[4;3H"++img},
    };
    var failures:usize=0;
    for(cases) |case| {
        var src=try testCreateTerminal(alloc,io,20,6,"");defer src.deinit(alloc);src.width_px=160;src.height_px=96;
        var input=src.vtStream();defer input.deinit();input.nextSlice(case.bytes);
        const snapshot=serializeTerminalState(alloc,&src) orelse return error.NoSnapshot;defer alloc.free(snapshot);
        var dst=try testCreateTerminal(alloc,io,20,6,"");defer dst.deinit(alloc);dst.width_px=160;dst.height_px=96;
        dst.modes.set(.grapheme_cluster,!src.modes.get(.grapheme_cluster));
        var output=dst.vtStream();defer output.deinit();output.nextSlice(snapshot);
        checkImageState(alloc,&src,&dst) catch |err| {std.debug.print("FAIL fresh {s}: {s}\n",.{case.name,@errorName(err)});failures+=1;continue;};
        for(0..50) |_| {const refresh=serializeVisibleTerminalState(alloc,&src) orelse return error.NoSnapshot;defer alloc.free(refresh);try testing.expect(std.mem.indexOf(u8,refresh,"\x1b_G")==null);output.nextSlice(refresh);}
        checkImageState(alloc,&src,&dst) catch |err| {std.debug.print("FAIL refresh {s}: {s}\n",.{case.name,@errorName(err)});failures+=1;continue;};
        if(std.mem.eql(u8,case.name,"unplaced")){input.nextSlice("\x1b_Ga=p,i=52,p=7,c=2,r=2,C=1,q=2\x1b\\");output.nextSlice("\x1b_Ga=p,i=52,p=7,c=2,r=2,C=1,q=2\x1b\\");try checkImageState(alloc,&src,&dst);}
        if(std.mem.startsWith(u8,case.name,"pending")){input.nextSlice("X");output.nextSlice("X");try checkImageState(alloc,&src,&dst);}
        if(std.mem.startsWith(u8,case.name,"both screens")){input.nextSlice("\x1b[?1049l");output.nextSlice("\x1b[?1049l");try checkImageState(alloc,&src,&dst);}
        if(std.mem.eql(u8,case.name,"short lines reflow")){try src.resize(alloc,.{.cols=10,.rows=6});try dst.resize(alloc,.{.cols=10,.rows=6});try checkImageState(alloc,&src,&dst);}
        if(std.mem.indexOf(u8,case.name,"history anchor")!=null){try src.resize(alloc,.{.cols=10,.rows=6});try dst.resize(alloc,.{.cols=10,.rows=6});try checkImageState(alloc,&src,&dst);}
        const nested=serializeTerminalState(alloc,&dst) orelse return error.NoSnapshot;defer alloc.free(nested);
        var third=try testCreateTerminal(alloc,io,dst.cols,dst.rows,"");defer third.deinit(alloc);third.width_px=dst.width_px;third.height_px=dst.height_px;
        var nested_input=third.vtStream();defer nested_input.deinit();nested_input.nextSlice(nested);try checkImageState(alloc,&dst,&third);
        std.debug.print("PASS {s}: fresh pixels, placements, cursor, text + 50 image-free refreshes + nested attach\n",.{case.name});
    }
    if(failures!=0)return error.ReplayMismatch;
}
