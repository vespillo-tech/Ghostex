Ghostex static Kitty image review package

EXACT REVIEW COMMITS. No main-app installation. Feature branches are on the contributor forks; coordinated draft PRs are being published.
Read review-overview.md first, then the two PR bodies and validation-report.txt.
Current target Ghostex main 56a620fe83132b7e77fed81e894ab8510f80b408 (26 files).
Use renderer-current-main.patch and publication-manifest.json. The original
renderer-candidate.patch targets reviewed main 270da410 and remains for traceability.
Current-main desktop and shared wasm compilation passed; original native
runtime acceptance used 270da410 with identical feature additions/deletions.
Target maddada/zmx NIGHTLY feaefff987232ed4628873eb6154813ea760f284 (7 files).
Apply with git apply --check, then git apply, in disposable checkouts.
Review/land zmx first; integrate its exact reviewed commit into Ghostex and
repeat focused gates. Current gitlink and wire generation 2 are unchanged.
wmx patch documents scope only; native Windows graphics remains separate.
Only Apple Silicon macOS runtime acceptance is claimed. Full limitations are
in both PR bodies. Mixed-mode history is a reproduced pre-existing limitation,
not a passing semantic-cell case; legacy reflow is the negative control.

Public replay reproduction (Zig 0.16):
  python3 probes/prepare-semantic-probe.py /absolute/path/to/patched/zmx
It copies source to a sibling directory and does not touch the checkout.
In that copy run zig build -Doptimize=Debug, then ./zig-out/bin/zmx.
For offline packages add --system /absolute/path/to/fetched/zig-pkg.
The public 39-case source/build matches the passing full harness's replay
prefix; full local harness also ran the separate supplied reflow/compatibility
snippets. Each of the 39 cases checks fresh state, 50 image-free refreshes and
nested attachment. The log retains negative controls and known limitations.
Local normal Zig build startup stalled, so cached source-matching build
runners were used; no stopped startup attempt is counted as passing.

Actual PTY checks (build candidate zmx first):
  export GX_IMAGE_ZMX=/absolute/path/to/patched/zmx/zig-out/bin/zmx
  GX_IMAGE_TAG=ordinary python3 probes/ordinary-capture.py
  GX_IMAGE_PNG=fixtures/showcase-checker.png GX_IMAGE_TAG=png python3 probes/ordinary-capture.py
  GX_IMAGE_CASE=placements-4096 GX_IMAGE_TAG=cap4096 python3 probes/zmx-candidate-probe.py
  GX_IMAGE_CASE=placements-4097 GX_IMAGE_TAG=cap4097 python3 probes/zmx-candidate-probe.py
  python3 probes/fractional-grid-claim-probe.py --expect-clean
For compatibility checks supply an old base binary separately:
  GX_IMAGE_OLD_ZMX=/absolute/path/to/base/zmx python3 probes/grid-sync-compatibility-probe.py
Each uses its own temporary ZMX_DIR and closes its fixture sessions.

Actual native model probe (POSIX, built renderer source required):
  python3 probes/compile-native-probe.py RENDERER_CHECKOUT CARGO_TARGET \
    --ghostty-lib-dir PATH_TO_BUILT_STATIC_VT_LIBRARY_DIRECTORY \
    --extern portable_pty=PATH_TO_RLIB --extern anyhow=PATH_TO_RLIB \
    --extern libc=PATH_TO_RLIB --extern image=PATH_TO_RLIB
Use matching release libraries from that renderer build (the same anyhow crate
identity as portable_pty); timestamps cannot identify compatible libraries.
The tool uses the production modules, writes a temporary standalone source and
prints its compiled binary path. It launches no app. Then:
  GX_IMAGE_NATIVE_PROBE=/path/printed/by/tool python3 probes/run-native-grid-sync-probe.py
The runner compares six quiet/append/overwrite cases and a pixel-only case
with the actual daemon and closes each disposable session.

Native public fixture in an explicitly authorized isolated app:
  python3 fixtures/image-fixture.py A
Open B in a second pane, use replace-tiny in A, search, resize and scroll B.
Quit/reopen only the viewer without redraw; both image forms should remain,
A solid green and B checker. Fixture ends after 15 minutes. CJK preedit,
deliberate link hover and other-platform acceptance remain open. This package
does not install, launch or restart an app. Reproduction tools are one-off
review artifacts outside repositories, not added repository tests.

Archive allowlist contains public fixture content, patches, PR bodies and
sanitized evidence. Private inventories, tokens/profiles, raw Claude outputs,
Beads, binaries/caches and historical screenshots are excluded. Source/hash
manifest omits private proof-directory paths. Build warnings remain visible.
