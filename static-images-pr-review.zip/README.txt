Ghostex static Kitty image review package

Current renderer audit headfc538d1a2a2fc190dd9725eb9782086fa51a25ed.
Read evidence/final-audit/AUDIT-REPORT.txt for new corrections, fresh native/ABI
evidence, actual Opus5.5 xhigh scope and remaining release/platform gates.
Earlier dated logs/sections retain historical scope.


EXACT REVIEW COMMITS. No main-app installation. Feature branches are on the contributor forks; coordinated draft PRs are published (Ghostex #186, zmx #3).
Read review-overview.md first, then the two PR bodies and validation-report.txt.
Tested target Ghostex main 56a620fe83132b7e77fed81e894ab8510f80b408 (28 files).
Use renderer-current-main.patch and publication-manifest.json. The original
renderer-candidate.patch targets reviewed main 270da410 and remains for traceability.
Current-main desktop and shared wasm compilation passed. The later three-file
CodeRabbit correction bounds uploads and suppresses placeholder cursor glyphs;
15 production-function checks and actual Opus5.5 xhigh review passed. The exact
Rust bytes also passed a fresh isolated native256-generation omission/recovery
check. A subsequent Help-only commit clarifies inherited10MB source storage.
CodeRabbit follow-up completed with no new actionable comments, but skipped
all3 correction files as similar; actual Claude/local checks cover the delta.
Read evidence/coderabbit-followup/checked-review-report.txt for limits/scope.
Target maddada/zmx NIGHTLY feaefff987232ed4628873eb6154813ea760f284 (7 files).
Apply with git apply --check, then git apply, in disposable checkouts.
Review/land zmx first; integrate its exact reviewed commit into Ghostex and
repeat focused gates. Current gitlink and wire generation 2 are unchanged.
wmx patch documents scope only; native Windows graphics remains separate.
Only Apple Silicon macOS runtime acceptance is claimed. Full limitations are
in both PR bodies. Mixed-mode history is a reproduced pre-existing limitation,
not a passing semantic-cell case; legacy reflow is the negative control.

Maintainer follow-up (2026-10-04): all six requests addressed. Read
 evidence/maintainer-review/checked-review-report.txt for precise dispositions.
Maintainer follow-up renderer4e58bf74a2a8bf063eb60911e4fd22da02f58b13 and zmx
ff399831abdc33e55c9841d324ff3bc70cfd7115 (comment-only follow-up).
Current patches: renderer-current-main.patch and zmx-current-review.patch.
Original candidate patches remain unchanged historical evidence. Fresh actual
native model image-failure/recovery, owned64MiB/256 admission,70,797 parser
boundary checks, optimized desktop/sharedwasm, and actual Opus5.5 xhigh passed.
A browser host bool/initializer needed mirroring and fresh compilation passed.
Audited main c5001c48f31e9dfde9783d75be84a9a865ba3e32 is source-compatible;
latest combined build is not claimed. No main-app installation/restart.

Focused native regressions (production build and matching libraries required):
 python3 evidence/maintainer-review/image-error-probe.py RENDERER_CHECKOUT LIB_DIRECTORY
 python3 evidence/maintainer-review/owned-image-probe.py RENDERER_CHECKOUT LIB_DIRECTORY
The image-error probe launches only a disposable shell PTY; ownership launches
no app. To repeat old negative controls add --baseline-source-dir
 evidence/maintainer-review/before --expect-freeze to the error probe; add
 --baseline-image-source evidence/maintainer-review/before/apps/desktop/src/ghostty_vt/images.rs
 --expect-unbounded to the ownership probe. Byte stress raises source storage
only in the disposable terminal; no settings or shared source policy changes.
 python3 evidence/maintainer-review/viewer-grid-probe.py
  evidence/maintainer-review/before/apps/desktop/src/terminal_model/viewer_grid.rs
  RENDERER_CHECKOUT/apps/desktop/src/terminal_model/viewer_grid.rs
Pass both parser paths on the same command line. Compiles copied source with
rustc1.95; split cases compare independent expected output and baseline. Timing
is isolated scanning, not whole-app performance or power. Cache caps don't
include prior-frameArcs/source/GPU memory. Broader UI/platform limits stay open.

Public replay reproduction (Zig 0.16):
  python3 probes/prepare-semantic-probe.py /absolute/path/to/patched/zmx
It copies source to a sibling directory and does not touch the checkout.
In that copy run zig build -Doptimize=Debug, then ./zig-out/bin/zmx.
For offline packages add --system /absolute/path/to/fetched/zig-pkg.
The public 39-case source/build matches the passing full harness's replay
prefix; full local harness also ran the separate supplied reflow/compatibility
snippets. Each of the 39 cases checks fresh state, 50 image-free refreshes and
nested attachment. The log retains negative controls and known limitations.
Local normal Zig build startup stalled, so cached source-matching build
runners were used; no stopped startup attempt is counted as passing.

Actual PTY checks (build candidate zmx first):
  export GX_IMAGE_ZMX=/absolute/path/to/patched/zmx/zig-out/bin/zmx
  GX_IMAGE_TAG=ordinary python3 probes/ordinary-capture.py
  GX_IMAGE_PNG=fixtures/showcase-checker.png GX_IMAGE_TAG=png python3 probes/ordinary-capture.py
  GX_IMAGE_CASE=placements-4096 GX_IMAGE_TAG=cap4096 python3 probes/zmx-candidate-probe.py
  GX_IMAGE_CASE=placements-4097 GX_IMAGE_TAG=cap4097 python3 probes/zmx-candidate-probe.py
  python3 probes/fractional-grid-claim-probe.py --expect-clean
For compatibility checks supply an old base binary separately:
  GX_IMAGE_OLD_ZMX=/absolute/path/to/base/zmx python3 probes/grid-sync-compatibility-probe.py
Each uses its own temporary ZMX_DIR and closes its fixture sessions.

Actual native model probe (POSIX, built renderer source required):
  python3 probes/compile-native-probe.py RENDERER_CHECKOUT CARGO_TARGET \
    --ghostty-lib-dir PATH_TO_BUILT_STATIC_VT_LIBRARY_DIRECTORY \
    --extern portable_pty=PATH_TO_RLIB --extern anyhow=PATH_TO_RLIB \
    --extern libc=PATH_TO_RLIB --extern image=PATH_TO_RLIB
Use matching release libraries from that renderer build (the same anyhow crate
identity as portable_pty); timestamps cannot identify compatible libraries.
The tool uses the production modules, writes a temporary standalone source and
prints its compiled binary path. It launches no app. Then:
  GX_IMAGE_NATIVE_PROBE=/path/printed/by/tool python3 probes/run-native-grid-sync-probe.py
The runner compares six quiet/append/overwrite cases and a pixel-only case
with the actual daemon and closes each disposable session.

Native public fixture in an explicitly authorized isolated app:
  python3 fixtures/image-fixture.py A
Open B in a second pane, use replace-tiny in A, search, resize and scroll B.
Quit/reopen only the viewer without redraw; both image forms should remain,
A solid green and B checker. Fixture ends after 15 minutes. CJK preedit,
deliberate link hover and other-platform acceptance remain open. This package
does not install, launch or restart an app. Reproduction tools are one-off
review artifacts outside repositories, not added repository tests.

Targeted upload admission and recovery fixture (terminal at least70x42):
  python3 evidence/coderabbit-followup/native-review-fixture.py
Wait for256 tiles, enter add (257th omitted), then recover (first2 deleted;
magenta257th appears without retransmission). Enter cursor for a placeholder
glyph-overlay check. Actual native focus was not independently established;
focused cursor semantics use the production-function probe. Ends after10min.
This tests count admission/recovery, not native GPU memory or64MiB capacity.
The library's existing10,000,000-byte/screen source-storage budget rejects a
16MiB RGBA asset; dimension/pixel caps are upper bounds. The synthetic byte
boundary probe does not establish that five large assets coexist by default.
Actual storage contrast using production VT and matching release libraries:
  python3 evidence/coderabbit-followup/storage-limit-probe.py RENDERER_CHECKOUT \
    LIBGHOSTTY_VT_DIRECTORY
It launches no app. Raising storage affects only a disposable in-memory VT;
application settings and source-storage policy remain unchanged.

Archive allowlist contains public fixture content, patches, PR bodies and
sanitized evidence. Private inventories, tokens/profiles, raw Claude outputs,
Beads, binaries/caches and historical screenshots are excluded. Source/hash
manifest omits private proof-directory paths. Build warnings remain visible.
