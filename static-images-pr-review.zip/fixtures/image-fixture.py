#!/usr/bin/env python3
"""Disposable full-app fixture: public pixels, static placeholders, ordinary image and text input."""
import base64, select, shutil, sys, time, os
from pathlib import Path
label=sys.argv[1] if len(sys.argv)>1 else "A"
out=sys.stdout.buffer
png=(Path(__file__).parent/"showcase-checker.png").read_bytes()
marks=["\u0305","\u030d","\u030e","\u0310","\u0312","\u033d"]
def emit(s):
    out.write(s.encode() if isinstance(s,str) else s);out.flush()
def at(r,c,s=""):emit(f"\x1b[{r};{c}H{s}")
def image(ctrl,pixels=b""):emit(b"\x1b_G"+ctrl.encode()+b";"+base64.b64encode(pixels)+b"\x1b\\")
def draw():
    emit("\x1b[2J\x1b[H\x1b[?25h")
    at(1,1,f"Image Lab pane {label} — public fixture / GPUI")
    at(2,1,"Search marker: IMAGECHECK   selectable text")
    at(3,1,"Ordinary PNG (restorable)");at(4,1)
    image("a=T,f=100,i=53,c=16,r=6,q=2",png)
    at(3,24,"Placeholder PNG (restorable)")
    image("a=T,f=100,i=52,c=16,r=6,U=1,q=2,z=-1",png)
    for row,mark in enumerate(marks):
        at(4+row,24,"\x1b[38;2;0;0;52m"+"\U0010eeee"+mark+marks[0]+"\U0010eeee"*15+"\x1b[0m")
    at(11,1,"Quadrants: red/green above blue/white")
    at(12,1,"\x1b[4mUnderline sample\x1b[0m   \x1b]8;;https://example.com\x1b\\Hover public link\x1b]8;;\x1b\\")
    at(14,1,"Typing/IME input below; cursor may blink normally.")
    at(15,1,"Control words: redraw, history, delete, replace, quit")
    at(17,1,f"pane-{label}> ")
draw()
end=time.monotonic()+900
while time.monotonic()<end:
    ready,_,_=select.select([sys.stdin],[],[],0.25)
    if not ready:continue
    line=sys.stdin.readline()
    if not line:break
    cmd=line.strip()
    if cmd=="quit":break
    if cmd=="history":
        emit("\x1b[24;1H")
        for n in range(65):emit(f"\r\nHISTORY {label} {n:02d} IMAGECHECK https://example.com")
        emit(f"\r\npane-{label}> ")
    elif cmd=="delete":image("a=d,d=I,i=52,q=2");at(18,1,"Placeholder asset deleted; ordinary asset unchanged")
    elif cmd in ("replace", "replace-tiny"):
        side=1 if cmd=="replace-tiny" else 16
        image(f"a=T,f=32,i=52,s={side},v={side},c=16,r=6,U=1,q=2,z=-1",bytes([30,230,100,255])*side*side)
        at(18,1,"Placeholder asset replaced with green")
    elif cmd=="ime":at(7,5)
    elif cmd=="redraw":draw()
    else:
        at(19,1,"\x1b[2KReceived: "+cmd);at(17,1,"\x1b[2K"+f"pane-{label}> ")
emit("\x1b[?25h\r\nDisposable fixture finished.\r\n")
