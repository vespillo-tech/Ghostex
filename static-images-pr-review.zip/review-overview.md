# Ghostex static terminal images — review overview

> **Maintainer follow-up (2026-10-04):** The [maintainer reviewed the contribution](https://github.com/maddada/Ghostex/pull/186#issuecomment-5975179787) and requested six changes. They are addressed at renderer `4e58bf74a2a8bf063eb60911e4fd22da02f58b13` and comment-only zmx `ff399831abdc33e55c9841d324ff3bc70cfd7115`. Fresh fault/ownership/scanner probes, optimized desktop and shared wasm compilation, and actual Opus 5.5 `xhigh` review passed. See the [six-request disposition](evidence/maintainer-review/checked-review-report.txt). Latest upstream `c5001c48f31e9dfde9783d75be84a9a865ba3e32` is source compatible; its full combined build remains an integration gate. Both PRs remain drafts pending the exact upstream zmx feature pin.

**Published as linked draft PRs:** [Ghostex #186](https://github.com/maddada/Ghostex/pull/186) and [zmx #3](https://github.com/maddada/zmx/pull/3). Both exact heads and scoped file lists are verified. Manual CodeRabbit reviews completed: zmx returned no actionable comments; two renderer findings were reproduced and corrected. The renderer follow-up completed with no new actionable comments, but skipped all three correction files as similar. Exact corrected Rust has actual Claude and local/native evidence. Macroscope skipped draft correctness review; actual Claude review evidence is documented below.

> **Historical publication revision (2026-10-03):** Ghostex main advanced to `56a620fe83132b7e77fed81e894ab8510f80b408`. That publication had review head `57a756dee3e84114f2e95d6c11ac03895b87950a` (26 files); the base update preserved every upstream change and feature addition/deletion; a subsequent three-file CodeRabbit correction is described below. The optimized desktop build and shared wasm compilation passed on this combined revision. Earlier native acceptance and full core evidence are retained below with their original base. The zmx head is unchanged. See the [current publication manifest](publication-manifest.json) and use `renderer-current-main.patch` for current main.


## Recommendation

**Worth proposing as two coordinated draft PRs.** This restores a useful terminal capability through the existing Ghostty, zmx and GPUI owners. The evidence supports the stated static-image scope on Apple Silicon macOS. It does not establish complete Kitty compatibility or readiness to release on every platform.

The maintainer reviewed the implementation, reported a successful local merge/build, and said they are happy to merge after six changes and zmx integration. The six changes are now addressed; upstream integration and the final merge decision remain theirs. The previous shader PR's [maintainer feedback](https://github.com/maddada/Ghostex/pull/183#issuecomment-5925770229) favors clear write-ups, pinned dependency source and concise customer Help. Those are the conventions followed here.

## What users gain

| Before | With both contributions |
| --- | --- |
| Retained image data has no GPUI painting path | Static ordinary and Unicode-placeholder images appear alongside terminal text. |
| Reconnecting loses retained pixels and placements | Supported images reappear without the producer sending them again. |
| Search/resize refresh erases ordinary placements | Text refresh preserves existing images without retransmitting graphics. |
| Viewer and daemon resize in different output order | Opted-in local viewers retain matching image anchors during reflow. |

This benefits terminal previews, image viewers and image-bearing TUIs that send supported Kitty commands. Public RGB/RGBA/PNG fixtures cover different identities, placements, panes and lifecycle events. Normal application autodetection is separate; LavaTUI still needs its own detection update.

## Why two PRs

```mermaid
flowchart LR
    A[Application Kitty commands] --> B[zmx retained state and replay]
    B --> C[Ghostty VT state]
    C --> D[Owned image frame]
    D --> E[Existing GPUI image painting]
```

| Contribution | Target and owner | Review starting point |
| --- | --- | --- |
| zmx replay and optional resize ordering | `maddada/zmx`, **nightly** at `feaefff987232ed4628873eb6154813ea760f284` | [zmx draft](zmx-pr-body.md), then `kitty_replay.zig`, `util.zig`, `ipc.zig`/`loop.zig` |
| Ghostex renderer and viewer integration | `maddada/Ghostex`, **main** at `56a620fe83132b7e77fed81e894ab8510f80b408` | [Ghostex draft](renderer-pr-body.md), then `ghostty_vt/images.rs`, `terminal_element/kitty_images.rs`, `terminal_model/viewer_grid.rs` |

zmx owns persistence for attached clients. Ghostex owns the final GPUI drawing. A renderer change alone cannot restore missing session state. A replay change alone cannot make GPUI paint that state.

The Ghostex candidate currently leaves its zmx gitlink unchanged. Review and land zmx first; then pin the exact reviewed commit and repeat integration checks. A dependent Ghostex draft must state that requirement prominently.

## Architecture and maintenance

- Reuse Ghostty's parser, image storage, placeholder iterator and geometry. The two small C API/resource patches are recorded in Ghostex's existing sync series.
- Copy retained state under exclusive VT access into owned generations. Reuse unchanged pixels and release replaced GPUI resources through the existing atlas lifecycle.
- Use existing cross-platform GPUI image APIs, clipping and z layers. No Zed edit or added dependency.
- Replay retained semantic state synchronously. No raw escape-history store or general rendering cache.
- Order daemon resize and output through one optional IPC advertisement. Existing tags, Init and wire generation **2** remain; old-daemon compatibility was exercised.
- Keep fixtures, instrumentation, profiles and private lab setup outside the submitted code.

Pixel-only resize updates apply to all TerminalViews, including local shells and shared browser code. Ordered daemon coordination is enabled only for local POSIX Agents/zmx. This wider pixel-metric change is disclosed for review.

## Evidence and limits

Start with the [validation report](validation-report.txt) for build logs, test counts and the native observation ledger. The [Claude review disposition](claude-checked-outcomes.txt) shows which findings were reproduced, corrected or retained as separate work. Actual reviews used Opus 5.5 with `xhigh` effort; later corrections were independently verified.

Verified native scenarios include ordinary and placeholder PNGs, active search highlights, pane splits, resizing, retained history, a tiny replacement, same-ID pane isolation and viewer quit/reopen without producer redraw. Automated evidence includes 39 semantic cases with 50 graphics-free refreshes each, 108 existing zmx tests, seven actual native-model cases, 11,593 stream-boundary cases, resource boundaries and old-daemon compatibility.

| Boundary | Meaning for review |
| --- | --- |
| Static explicit-ID RGB/RGBA/decoded PNG | Advertised restoration contract. Animation, relative replay, numbered/implicit identities and pending transfers are excluded. |
| Resource budgets | 4096 per side and 4 Mi pixels/image within the inherited 10 MB source-storage budget/screen; replay 16 MiB decoded bytes/screen and 4096 assets/placements. Owned RGBA copies are independently capped at 64 MiB/256 assets per terminal; GPUI padded uploads at 64 MiB/256 generations per view. Decoder caps apply after buffering; inherited transfer limits and total process/GPU memory remain separate. |
| Platform evidence | Apple Silicon macOS runtime verified. Linux, native Windows, Intel and native mixed-DPI acceptance remain unverified. Browser Kitty storage is disabled; wmx retains no graphics state. |
| Existing snapshot issues | Mixed historical mode-2027 widths differ on base and candidate. A controlled pre-Init partial-UTF-8 case leaves an extra replacement character on both; it is a separate existing issue. |
| UI acceptance | CJK preedit and deliberate link hover remain unverified. Committed dead-key text is not proof of IME composition. |

The full unfiltered Debug core gate passed **6,472 tests with 52 skips** across both roots. The exact upstream baseline passed the same counts. Both full runs take several minutes; the earlier incomplete run is superseded by these completed gates. Details are in the validation report.

## Publication and release boundary

Local heads are preserved as renderer `dacecf7f0e188e1bbea0e53880045af7c9a6cd7c` and zmx `c630130eb7aa007407d6f63d0c77932009798e16`, each directly based on its target revision. Both development checkouts remain intact. The linked drafts above use contribution branches on the contributor's forks. Do not push to maintainer branches or install this validation build into the main app.

Before release, integrate the exact reviewed zmx pin, repeat focused builds/attachment checks at that pin, and obtain the maintainer's decision on the bounded protocol/platform scope. The separate existing snapshot issues stay visible in the review; this contribution does not claim to solve them.

[Public review archive](README.txt) · [Current renderer patch](renderer-current-main.patch) · [zmx patch](zmx-replay-candidate.patch)

## Previous publication check (2026-10-03)

Upstream main subsequently advanced to `993eba2f3b004d84083e2baaf2f04c37c35a23f0` with release/server/modal refactors, Windows SSH setup and fish agent-launch fixes. The only shared file is Help: upstream changes its Windows SSH paragraph, while this feature changes Terminal images. The current feature patch applies cleanly to that revision in a disposable index and preserves all upstream changes; the PR is mergeable. This is a source compatibility check, not a build or native run of that latest combination. The tested renderer base remains `56a620fe83132b7e77fed81e894ab8510f80b408`; zmx nightly is unchanged. The exact reviewed zmx pin and repeated integration/build checks remain the release gate.

## CodeRabbit follow-up

Two renderer findings were reproduced and fixed in the three-file Rust/Help correction at `c6f98a96e3466c16945b7544ad629a27c28a1b82`: suppress native placeholder cursor glyphs and admit padded uploads within 64 MiB/256 generations per view. All 15 production-function checks, scoped formatting, optimized desktop build (5m44s), shared wasm compilation (9.96s) and actual Opus 5.5 `xhigh` delta review passed. No core/zmx source changed. Those correction bytes matched that reviewer input; the later maintainer delta has separate review evidence. A subsequent Help-only commit `57a756dee3e84114f2e95d6c11ac03895b87950a` explains the inherited 10 MB source-storage limit.

The [CodeRabbit follow-up](https://github.com/maddada/Ghostex/pull/186#issuecomment-5967660725) completed with no new actionable comments, but skipped all three correction files as similar to previously reviewed changes. It is not independent approval of the corrected delta. Its default docstring-coverage advisory (41.86%, threshold 80%) is not a required GitHub check; the required storage-access check passed. Existing ownership/resource documentation and focused function comments remain the review material; no repetitive comments were added solely for that metric.

A fresh optimized isolated full Image Lab (3m23s build) exercised these exact Rust bytes on Apple Silicon macOS: 256 tiny image generations stayed visible; the 257th was omitted while full; deleting two retained images made the omitted image appear without retransmission, with the remaining artwork intact. The green Unicode-placeholder fixture showed a visible block cursor without a missing-glyph overlay. OS focus was not independently established, so the focused cursor case relies on the production-function probe. This was a targeted native follow-up, not a repeat of every earlier UI scenario or a GPU-memory measurement.

The library's existing source-storage budget is **10,000,000 bytes per screen**, not standalone Ghostty's 320 MB default. A 16 MiB RGBA transfer was refused under the unchanged library default and the identical transfer succeeded only after raising storage in a disposable in-memory VT probe. No application storage policy was changed. The 64 MiB upload byte-boundary probe uses synthetic frames; its five maximum-size inputs cannot coexist under the current default VT budget. The count-limit recovery above was verified in the real app. Temporary lab configuration overrides were restored, all owned lab processes/sessions closed, and the installed app/server remained unchanged and authenticated.

See the [checked follow-up report](evidence/coderabbit-followup/checked-review-report.txt), [native observation ledger](evidence/coderabbit-followup/native-review-observations.json) and [storage-limit probe results](evidence/coderabbit-followup/storage-limit-probe.log). The exact reviewed upstream zmx feature pin and repeated integration checks remain the release gate; both PRs stay drafts.
