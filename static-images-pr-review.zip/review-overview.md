# Ghostex static terminal images — review overview

**Published as linked draft PRs:** [Ghostex #186](https://github.com/maddada/Ghostex/pull/186) and [zmx #3](https://github.com/maddada/zmx/pull/3). Both exact heads and scoped file lists are verified. CodeRabbit explicitly skipped automatic review for draft PRs, and Macroscope reported SKIPPED; the local Claude review evidence is documented below.

> **Publication revision update (2026-10-03):** Ghostex main advanced to `56a620fe83132b7e77fed81e894ab8510f80b408`. The image contribution now has review head `a5011395da6827874e9c47d548b8094f7116a84d` (26 files); all feature additions/deletions and all upstream changes are preserved. The optimized desktop build and shared wasm compilation passed on this combined revision. Earlier native acceptance and full core evidence are retained below with their original base. The zmx head is unchanged. See the [current publication manifest](publication-manifest.json) and use `renderer-current-main.patch` for current main.


## Recommendation

**Worth proposing as two coordinated draft PRs.** This restores a useful terminal capability through the existing Ghostty, zmx and GPUI owners. The evidence supports the stated static-image scope on Apple Silicon macOS. It does not establish complete Kitty compatibility or readiness to release on every platform.

The maintainer has not requested or approved this image implementation. Its value is our recommendation based on reproduced failures and verified improvements. The previous shader PR's [maintainer feedback](https://github.com/maddada/Ghostex/pull/183#issuecomment-5925770229) favors clear write-ups, pinned dependency source and concise customer Help. Those are the conventions followed here.

## What users gain

| Before | With both contributions |
| --- | --- |
| Retained image data has no GPUI painting path | Static ordinary and Unicode-placeholder images appear alongside terminal text. |
| Reconnecting loses retained pixels and placements | Supported images reappear without the producer sending them again. |
| Search/resize refresh erases ordinary placements | Text refresh preserves existing images without retransmitting graphics. |
| Viewer and daemon resize in different output order | Opted-in local viewers retain matching image anchors during reflow. |

This benefits terminal previews, image viewers and image-bearing TUIs that send supported Kitty commands. Public RGB/RGBA/PNG fixtures cover different identities, placements, panes and lifecycle events. Normal application autodetection is separate; LavaTUI still needs its own detection update.

## Why two PRs

```mermaid
flowchart LR
    A[Application Kitty commands] --> B[zmx retained state and replay]
    B --> C[Ghostty VT state]
    C --> D[Owned image frame]
    D --> E[Existing GPUI image painting]
```

| Contribution | Target and owner | Review starting point |
| --- | --- | --- |
| zmx replay and optional resize ordering | `maddada/zmx`, **nightly** at `feaefff987232ed4628873eb6154813ea760f284` | [zmx draft](zmx-pr-body.md), then `kitty_replay.zig`, `util.zig`, `ipc.zig`/`loop.zig` |
| Ghostex renderer and viewer integration | `maddada/Ghostex`, **main** at `270da410af86aa4d7875bdc8637cc0795ffa581c` | [Ghostex draft](renderer-pr-body.md), then `ghostty_vt/images.rs`, `terminal_element/kitty_images.rs`, `terminal_model/viewer_grid.rs` |

zmx owns persistence for attached clients. Ghostex owns the final GPUI drawing. A renderer change alone cannot restore missing session state. A replay change alone cannot make GPUI paint that state.

The Ghostex candidate currently leaves its zmx gitlink unchanged. Review and land zmx first; then pin the exact reviewed commit and repeat integration checks. A dependent Ghostex draft must state that requirement prominently.

## Architecture and maintenance

- Reuse Ghostty's parser, image storage, placeholder iterator and geometry. The two small C API/resource patches are recorded in Ghostex's existing sync series.
- Copy retained state under exclusive VT access into owned generations. Reuse unchanged pixels and release replaced GPUI resources through the existing atlas lifecycle.
- Use existing cross-platform GPUI image APIs, clipping and z layers. No Zed edit or added dependency.
- Replay retained semantic state synchronously. No raw escape-history store or general rendering cache.
- Order daemon resize and output through one optional IPC advertisement. Existing tags, Init and wire generation **2** remain; old-daemon compatibility was exercised.
- Keep fixtures, instrumentation, profiles and private lab setup outside the submitted code.

Pixel-only resize updates apply to all TerminalViews, including local shells and shared browser code. Ordered daemon coordination is enabled only for local POSIX Agents/zmx. This wider pixel-metric change is disclosed for review.

## Evidence and limits

Start with the [validation report](validation-report.txt) for build logs, test counts and the native observation ledger. The [Claude review disposition](claude-checked-outcomes.txt) shows which findings were reproduced, corrected or retained as separate work. Actual reviews used Opus 5.5 with `xhigh` effort; later corrections were independently verified.

Verified native scenarios include ordinary and placeholder PNGs, active search highlights, pane splits, resizing, retained history, a tiny replacement, same-ID pane isolation and viewer quit/reopen without producer redraw. Automated evidence includes 39 semantic cases with 50 graphics-free refreshes each, 108 existing zmx tests, seven actual native-model cases, 11,593 stream-boundary cases, resource boundaries and old-daemon compatibility.

| Boundary | Meaning for review |
| --- | --- |
| Static explicit-ID RGB/RGBA/decoded PNG | Advertised restoration contract. Animation, relative replay, numbered/implicit identities and pending transfers are excluded. |
| Resource budgets | 4096 per side, 4 Mi pixels/image; replay 16 MiB decoded bytes/screen and 4096 assets/placements. Decoder caps apply after buffering. The inherited 400 MiB transfer/decompression ceiling and aggregate memory remain separate. |
| Platform evidence | Apple Silicon macOS runtime verified. Linux, native Windows, Intel and native mixed-DPI acceptance remain unverified. Browser Kitty storage is disabled; wmx retains no graphics state. |
| Existing snapshot issues | Mixed historical mode-2027 widths differ on base and candidate. A controlled pre-Init partial-UTF-8 case leaves an extra replacement character on both; it is a separate existing issue. |
| UI acceptance | CJK preedit and deliberate link hover remain unverified. Committed dead-key text is not proof of IME composition. |

The full unfiltered Debug core gate passed **6,472 tests with 52 skips** across both roots. The exact upstream baseline passed the same counts. Both full runs take several minutes; the earlier incomplete run is superseded by these completed gates. Details are in the validation report.

## Publication and release boundary

Local heads are preserved as renderer `dacecf7f0e188e1bbea0e53880045af7c9a6cd7c` and zmx `c630130eb7aa007407d6f63d0c77932009798e16`, each directly based on its target revision. Both development checkouts remain intact. The linked drafts above use contribution branches on the contributor's forks. Do not push to maintainer branches or install this validation build into the main app.

Before release, integrate the exact reviewed zmx pin, repeat focused builds/attachment checks at that pin, and obtain the maintainer's decision on the bounded protocol/platform scope. The separate existing snapshot issues stay visible in the review; this contribution does not claim to solve them.

[Public review archive](README.txt) · [Renderer patch](renderer-candidate.patch) · [zmx patch](zmx-replay-candidate.patch)

## Latest publication check

Upstream advanced again to `cc83fc9c904c329f363791afb2dec22cd575e86a` while publication was running. Its four changes concern Windows server launch warnings and do not overlap the image contribution. The PR is mergeable. The tested renderer base remains `56a620fe83132b7e77fed81e894ab8510f80b408`; the zmx nightly base is unchanged. The published archive, heads and file lists are verified; the exact zmx pin and repeat integration remain the release gate.
