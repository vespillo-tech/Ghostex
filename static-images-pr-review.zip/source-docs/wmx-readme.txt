# wmx

Persistent Windows terminal sessions backed by ConPTY. wmx is the Windows counterpart to [Ghostex's zmx fork](https://github.com/maddada/zmx). It implements the terminal session features used by Ghostex desktop, web, and mobile, with PowerShell sessions that survive client disconnection and gxserver restarts.

Build on Windows with Rust 1.89 or newer and the MSVC toolchain:

```powershell
cargo build --release --locked
./tests/windows-smoke.ps1 -WmxExe ./target/release/wmx.exe
```

Windows 10 version 1809 or newer is required for ConPTY. PowerShell 7 is recommended; Windows PowerShell 5.1 also works. wmx is an independent MIT-licensed program, extracted from Ghostex's original `ghostex-session-host.exe`.

## Session API

| Operation     | wmx interface                                                              | zmx behavior preserved                                                                                  |
| ------------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| Start         | `start` with one JSON line on stdin, or `start-encoded BASE64_JSON`        | Idempotent detached session creation; existing sessions keep their process and environment. A new session reads the current Machine and User environment from the registry, like a new Windows Terminal tab, so its PATH includes tools installed after the caller started. |
| Attach        | `attach NAME [--require-existing] [--prompt-editor monaco\|code-server]`   | Snapshot followed by live VT output, raw input, reconnect, and Ctrl-\\ detach.                          |
| Inventory     | `list [--short]`, `exists NAME`, `grid NAME`                               | Named sessions, liveness, and display leadership/grid metadata.                                         |
| Input         | `send NAME [TEXT ...]`, or raw bytes on stdin                              | Input is delivered to the existing PTY; stdin is bounded to 1 MiB.                                      |
| History       | `history NAME [--vt] [--scrollback N]`                                     | Plain text or VT screen plus bounded scrollback.                                                        |
| Display       | `resize NAME ROWS COLS`, `refresh NAME`, `refresh-if-stale NAME ROWS COLS` | Atomic stale-grid comparison and refreshed snapshots.                                                   |
| Titles        | `watch-title NAME`                                                         | JSON lines, semantic debounce at 1 second, spinner heartbeat at 2 seconds, maximum settle at 6 seconds. |
| Prompt editor | `prompt-editor-capability [NAME]`                                          | Active visible client's editor capability, otherwise `editor`.                                          |
| Detach        | `detach [NAME]`                                                            | Disconnect clients while the shell stays alive.                                                         |
| Stop          | `kill NAME ...`                                                            | Wait for daemon cleanup before returning, allowing immediate restart.                                   |
| Compatibility | `version`                                                                  | Includes a `wire_generation` line used by Ghostex's compatibility cycle.                                |

Aliases: `a`, `l`/`ls`, `s`, `hi`, `d`, `k`, and `v`. An attachment always requires an existing session. Unlike zmx's command-line `run`, the start interface carries native Windows paths and startup code as structured JSON:

```powershell
@{
  name = 'work'
  cwd = $HOME
  shell = (Get-Command pwsh.exe).Source
  startup = "Write-Output 'Ready'"
} | ConvertTo-Json -Compress | ./target/release/wmx.exe start
./target/release/wmx.exe attach work
```

The shell receives `WMX_SESSION` and `ZMX_SESSION`. `WMX_DIR` chooses the session registry; the default is `%LOCALAPPDATA%/wmx/sessions`. Ghostex sets its own registry directory and agent environment through its server adapter. wmx contains no Ghostex path or prompt-editor setup policy.

`inspect NAME` reports registry/process liveness without asking the daemon to answer IPC. `kill --force NAME` is explicit recovery for an incompatible or unresponsive daemon. It verifies the process image and creation time before terminating the recorded owner, protecting against reused PIDs.

## Shared behavior and maintenance

Formatted history exports physical rows with literal padding and SGR styles, matching the chat parser contract. Plain history exports the same physical rows without styling, so a row that fills the last column keeps its own line instead of being glued to the row below it. Attachment snapshots separately restore cursor position and terminal modes.

`vendor/vt100` contains the source and MIT license from the crates.io `vt100` 0.16.2 release. Its primary-grid resize preserves rows displaced above the cursor in scrollback before ConPTY repaints a smaller viewport. Upstream's `set_size` truncates those rows, so attaching a short Actions pane could permanently erase the first command output. The patch operates on the grid directly to preserve the live parser's partial escape sequences, scroll regions, styles, and saved cursor. zmx already preserves displaced rows through Ghostty's terminal resize; this Windows implementation change does not alter the wire generation.

This is API and behavior compatibility, not zmx binary wire compatibility. wmx uses authenticated, bounded JSON frames over per-session loopback TCP. Registry records contain a random per-session token. zmx uses its Unix IPC protocol. Keep registry data private to the Windows account.

Every change to a Ghostex-consumed zmx feature must be reviewed against this table and the corresponding wmx modules:

`send` and `attach` translate character CSI-u keys, standalone Escape, and Unicode input into ConPTY's Win32 input records in `src/console_input.rs`. This preserves modified Enter/Tab, dialog controls, and Unicode text for console-record applications such as Codex. Attachments request enhanced keyboard reporting and restore the previous mode when they close. Conversion is client-side, so existing generation-1 daemons benefit without restarting their sessions; an already attached client must reconnect to use the updated executable. Other escape sequences, bracketed-paste boundaries, and split UTF-8 are retained across attachment reads. POSIX zmx needs no conversion: its PTYs deliver VT directly to the application. This does not change IPC or the wire generation.

| Shared contract                                                                     | zmx source                     | wmx source                                               |
| ----------------------------------------------------------------------------------- | ------------------------------ | -------------------------------------------------------- |
| Visible/chat/parked clients, latest active visible leader, 200-column resting width | `src/loop.zig`, `src/ipc.zig`  | `src/display.rs`, `src/daemon.rs`                        |
| `ZMX_VISIBLE`, `ZMX_CHAT`, `ZMX_HIDDEN`, `ZMX_REFRESH` private OSCs                 | `src/loop.zig`                 | `src/input.rs`, `src/attachment.rs`                      |
| Screen/history and refresh                                                          | `src/loop.zig`                 | `src/history.rs`, `src/daemon.rs`                        |
| Static Kitty image attachment replay | `src/kitty_replay.zig`, `src/util.zig` | Not implemented: vt100 retains no APC/image state; native ConPTY graphics passthrough unverified. |
| Optional ordered image-grid records | `src/ipc.zig`, `src/loop.zig` | Not needed here: native Ghostex opts in only for POSIX zmx; wmx keeps its existing resize/refresh path. |
| Titles and spinner normalization                                                    | `src/title_events.zig`         | `src/title_events.rs`, `src/callbacks.rs`                |
| Prompt-editor client capability                                                     | `src/ipc.zig`, `src/loop.zig`  | `src/display.rs`, `src/attachment.rs`                    |
| Detached lifecycle and recovery                                                     | `src/main.zig`, `src/loop.zig` | `src/launch.rs`, `src/client.rs`, `src/process_owner.rs` |

Ghostex's adapters live in `server/src/zmx/scripts.rs` and `scripts_windows.rs`. The desktop, web, and mobile private OSC emitters stay byte-identical. Wire generations are independent between providers. Bump wmx's `WIRE_GENERATION` in `src/protocol.rs` only when old daemons cannot serve new clients; probe additive capabilities so compatible daemons survive app updates. The original session-host protocol is generation 1 and remains supported.

Run the Windows smoke script after changes to either side of these contracts. It exercises real ConPTY sessions, delayed first requests, competing attachments, display leadership, prompt-editor handoff, persistent shell/history, stdin EOF, and graceful/forced shutdown.

## Future work

Kitty graphics replay requires a separate Windows design: the current vt100 parser does not retain image assets or placements. Implementing this needs a graphics-capable parser and state model, plus native ConPTY verification. The POSIX replay candidate does not change Windows IPC, lifecycle, or rendering. Its optional GridSync tag and attach-scoped record adapter are enabled only for local POSIX agent viewers; the native Windows adapter sends no advertisement and keeps its existing resize/refresh behavior. wmx does not track a program's synchronized-output mode, so zmx's conditional refresh terminator has no matching retained mode to preserve here.

Features Ghostex does not currently require remain future work: arbitrary executable `run`/`r` syntax and implicit attach-or-create, session labels and rename, HTML history export, key-name send syntax, detach-all across all sessions, arbitrary non-PowerShell shells, and upstream zmx features outside the table. They should be added when a Ghostex client needs them, with the corresponding zmx behavior documented and verified.
