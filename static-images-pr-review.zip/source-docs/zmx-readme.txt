<h1>
<p align="center">
  <img src="./logo.png" alt="Logo" width="128">
  <br>zmx
</h1>
<p align="center">
  Session attach/detach for the terminal.
  <br />
  <a href="https://zmx.sh">Docs</a>
  ·
  <a href="https://bower.sh/you-might-not-need-tmux">You might not need tmux</a>
  ·
  Sponsored by <a href="https://pico.sh">pico.sh</a>
</p>

## features

- Persist terminal shell sessions
- Ability to attach and detach from a shell session without it being killed
- Native terminal scrollback
- Multiple clients can connect to the same session
- Re-attaching to a session restores previous terminal state and output
- Send commands to a session without attaching to it
- Print scrollback history of a terminal session in plain text
- Works on mac and linux
- This project does **NOT** provide windows, tabs, or splits

## Kitty image restoration (local candidate)

Fresh attachments replay static Kitty RGB/RGBA assets with explicit image IDs,
including decoded PNGs, ordinary pinned placements, Unicode-placeholder (`U=1`)
placements, mixed placements and retained unplaced assets. PNGs use Ghostty's
pinned Wuffs decoder. Base64 payloads are chunked to 4096 bytes and every
command suppresses replies. Ordinary history pins are placed while their row
is still addressable. Primary state is restored before an active alternate
screen. An inactive alternate buffer is not reconstructed on primary attach.

In-place refresh clears text with ED0 and emits no image commands. This keeps
ordinary, virtual and straddling history placements alive without duplicating
internal placement IDs or replacing retained pixels. The viewport is formatted
before application modes, margins and cursor state are restored. Grapheme
clustering mode is restored before any text because it changes cell widths.
As with the existing text snapshot, history printed under differing grapheme
clustering modes is replayed using the final global mode. Retained text can be
identical while historical cell widths differ. Arbitrary saved cursor slots
are also outside the snapshot contract.

Replay is limited to 4096 on each side, 4 Mi pixels per image, 16 MiB of decoded
pixel bytes per screen, and 4096 eligible assets/placements. Exceeding an entry
cap omits that screen's image replay. Within the byte budget, visible/virtual
assets take priority over history and unplaced assets, followed by image ID.
The replay borrows Ghostty's retained state synchronously; it stores no raw
escape history. Original explicit image and placement IDs are preserved;
internal placement IDs are assigned by the receiving parser.

Relative placements, animation state, pending data, numbered (`I=`) and implicit
image identities are not reconstructed. Explicit replay cannot preserve a
number alias or the implicit allocator counter. The decoder rejects PNG input
above 16 MiB after buffering and applies the same dimension/pixel bounds. The
core's existing transmission/decompression ceiling remains 400 MiB; decoded
replay limits do not bound all in-flight storage. Raw image storage and transmission
permissions are unchanged. Rejected PNG input is still passed live to the
client but has no retained daemon asset for a future attachment.

This candidate is verified on macOS arm64. Linux runtime behavior is unverified.
Windows uses wmx, whose vt100 parser retains no Kitty graphics state; replay
there requires a separate parser/state design and native ConPTY verification.
The existing IPC tags and Init payload are unchanged. An optional `GridSync`
tag (210) advertises ordered resize records; wire generation remains 2. A
nonce-enabled attach sends the empty advertisement before Init. The daemon
queues grid/pixel dimensions after each actual resize and before later output,
including an initial baseline for sessions that have not emitted text.
Unchanged claims emit no record or repaint; initial attachment supplies a
baseline even if no resize is needed. Existing automatic refresh
remains after the record and preserves an open program synchronized update.

The native Ghostex adapter opts in only for local POSIX agent viewers. It removes
fixed nonce-scoped records before feeding Ghostty, so even a record between
UTF-8, CSI or graphics bytes cannot interrupt the VT parser. The token is removed
before session creation and excluded from tracked environment variables; it
belongs to one attach generation, not the program or daemon. Only negotiated
viewers defer their VT resize until the daemon's ordered record. Old daemons
ignore the new tag, receive the existing Init, and leave the host on immediate
resize/refresh behavior. Non-advertising clients receive no records. No session
restart is forced; an older daemon needs natural replacement for new replay.
Remote viewers, browser/mobile clients and wmx remain on their existing path.

## demos

- [zmx - intro](https://youtu.be/UIXj0_rhPgI)
- [zmx - ai portal](https://youtu.be/CV3skPYHP4Q)

## install

### binaries

- https://zmx.sh/a/zmx-0.8.1-linux-aarch64.tar.gz
- https://zmx.sh/a/zmx-0.8.1-linux-x86_64.tar.gz
- https://zmx.sh/a/zmx-0.8.1-macos-aarch64.tar.gz
- https://zmx.sh/a/zmx-0.8.1-macos-x86_64.tar.gz

### homebrew

```bash
brew install neurosnap/tap/zmx
```

### mise-en-place

```bash
mise use zmx
```

### NixOS / nixpkgs

Run immediately without installation:

```sh
nix run github:NixOS/nixpkgs/nixpkgs-unstable#zmx
# or build main yourself
nix run github:neurosnap/zmx
```

Start a shell with zmx available while it runs:

```sh
nix shell github:NixOS/nixpkgs/nixpkgs-unstable#zmx
# or built main yourself
nix run github:neurosnap/zmx
```

### packages (unofficial)

- [Alpine Linux](https://pkgs.alpinelinux.org/package/edge/testing/x86_64/zmx)
- [Arch AUR tracking releases](https://aur.archlinux.org/packages/zmx)
- [Arch AUR tracking git](https://aur.archlinux.org/packages/zmx-git)
- [openSUSE Tumbleweed](https://software.opensuse.org/package/zmx)
- [Gentoo (overlay)](https://codeberg.org/samuelhautamaki/samuelhautamaki-gentoo)
- [zmx-rpm packaging](https://github.com/engie/zmx-rpm/)

### src

- Requires zig `v0.16`
- Clone the repo
- Run build cmd

Be sure to add `~/.local/bin` to your `PATH`:

```bash
zig build -Doptimize=ReleaseSafe --prefix ~/.local
```

## usage

> [!IMPORTANT]
> We recommend closing the terminal window to detach from the session but you can also press `ctrl+\` or run `zmx detach`. If you need `ctrl+\` for something else (e.g. vim's `ctrl+\ ctrl+n` to escape its own `:terminal`), set `ZMX_NO_DETACH_KEY` to disable the shortcut and rely on `zmx detach` or closing the window instead.

Run `zmx help` for more information on usage, with examples.

```
Usage: zmx <command> [args...]

Commands:
  [a]ttach <name> [command...]             Attach to session, creating if needed
  [r]un <name> [-d] [command...]           Send command without attaching
  [s]end <name> <text...>                  Send raw input to session PTY
  [p]rint <name> <text...>                 Inject text into session display
  [wr]ite <name> <file_path>               Write stdin to file_path through the session
  [d]etach                                 Detach all clients (ctrl+\\ for current client)
  [l]ist|ls [--short]                      List active sessions
  [g]et <name>                             Get session labels
  set <name> k=v ...                       Set session labels
  [cl]ear <name>                           Clear all session labels
  print-env [-s] <name> [key]              Print tracked environment variables
  [k]ill <name>... [--force]               Kill session and all attached clients
  [hi]story <name> [--vt|--html]           Output session scrollback
  [w]ait <name>...                         Wait for session tasks to complete
  [t]ail <name>...                         Follow session output
  [c]ompletions <shell>                    Shell completions (bash, zsh, fish, nu, yash)
  [v]ersion                                Show version and metadata (socket dir, log dir)
  [h]elp                                   Show this help
```

### screen and scrollback capture

`zmx history --screen <name>` prints only the active screen, and
`zmx history --scrollback N <name>` adds up to `N` rows of scrollback above it.
Both work with `--vt` and `--html`. The daemon selects the rows before
formatting them, so a tool that polls a session's current state no longer
receives and discards the whole history. Alternate screens have no scrollback,
so they always return just the screen. Sessions whose daemon predates this
feature keep serving plain `history`; the scoped flags report that the daemon
is too old.

## nested sessions

Nested sessions are not supported. Inside a session `ZMX_SESSION` is set, and `attach` reads it: instead of creating another client it switches the calling terminal to the session you named.

That matters when the variable is inherited rather than chosen. A script, build tool, or coding agent started inside a session runs with `ZMX_SESSION` set, so `zmx attach other` from there moves the terminal somebody was using, and the session it was showing is left with no client.

Unset it in anything that attaches on its own behalf:

```bash
env -u ZMX_SESSION zmx attach other
```

For non-interactive work prefer `zmx run`, which never switches the caller.

## shell prompt

When you attach to a `zmx` session, we don't provide any indication that you are inside `zmx`. We do provide an environment variable `ZMX_SESSION` which contains the session name.

We recommend checking for that env var inside your prompt and displaying some indication there.

### fish

Place this file in `~/.config/fish/config.fish`:

```fish
functions -c fish_prompt _original_fish_prompt 2>/dev/null

function fish_prompt --description 'Write out the prompt'
  if set -q ZMX_SESSION
    echo -n "[$ZMX_SESSION] "
  end
  _original_fish_prompt
end
```

### bash and zsh

Depending on the shell, place this in either `.bashrc` or `.zshrc`:

```bash
if [[ -n $ZMX_SESSION ]]; then
  export PS1="[$ZMX_SESSION] ${PS1}"
fi
```

### powerlevel10k zsh theme

[powerlevel10k](https://github.com/romkatv/powerlevel10k) is a theme for zsh that overwrites the default prompt statusline.

Place this in `.zshrc`:

```bash
function prompt_my_zmx_session() {
  if [[ -n $ZMX_SESSION ]]; then
    p10k segment -b '%k' -f '%f' -t "[$ZMX_SESSION]"
  fi
}
POWERLEVEL9K_RIGHT_PROMPT_ELEMENTS+=my_zmx_session
```

### oh-my-posh

[oh-my-posh](https://ohmyposh.dev) is a popular shell themeing and prompt engine. This code will display an icon and session name as part of the prompt if (and only if) you have zmx active:

```toml
[[blocks.segments]]
   template = '{{ if .Env.ZMX_SESSION }} {{ .Env.ZMX_SESSION }}{{ end }}'
   foreground = 'p:orange'
   background = 'p:black'
   type = 'text'
   style = 'plain'
```

### Starship

[Starship](https://starship.rs) is a popular shell themeing and prompt engine. This code will display an icon and session name as part of the prompt if (and only if) you have zmx active:

```toml
format = """
${env_var.ZMX_SESSION}\
...
"""

[env_var.ZMX_SESSION]
symbol = " "
format = "[$symbol$env_value]($style) "
description = "zmx session name"
style = "bold magenta"
```

## environment variables

A session's environment is initialized when the session is created. When re-attaching from a new terminal or a different SSH connection, environment variables describing the client connection (such as `SSH_AUTH_SOCK`, `DISPLAY`, or terminal remote control variables like `KITTY_LISTEN_ON`, `KITTY_PID`, `KITTY_WINDOW_ID`) become outdated in the running shell.

`zmx` tracks these environment variables from attaching clients. You can inspect the current leader client's environment with `zmx print-env`:

```bash
# Print all tracked environment variables (set variables as KEY=VALUE, unset as -KEY)
zmx print-env .
zmx print-env dev

# Print POSIX shell commands (export ... / unset ...) suitable for eval
zmx print-env -s .

# Print a specific variable value
zmx print-env . SSH_AUTH_SOCK
```

You can automatically update your shell environment before each prompt:

### bash

Add to `~/.bashrc`:

```bash
_zmx_env_hook() {
  if [[ -n $ZMX_SESSION ]]; then
    eval "$(zmx print-env -s .)"
  fi
}
PROMPT_COMMAND="_zmx_env_hook${PROMPT_COMMAND:+; $PROMPT_COMMAND}"
```

### zsh

Add to `~/.zshrc`:

```zsh
precmd() {
  if [[ -n $ZMX_SESSION ]]; then
    eval "$(zmx print-env -s .)"
  fi
}
```

### fish

Add to `~/.config/fish/config.fish`:

```fish
function _zmx_env_hook --on-event fish_prompt
  if test -n "$ZMX_SESSION"
    for line in (zmx print-env .)
      if string match -q -- "-*" $line
        set -e (string sub -s 2 $line)
      else
        set -gx (string split -m 1 "=" $line)
      end
    end
  end
end
```

### configuring tracked variables

By default, `zmx` tracks:

- `DISPLAY`
- `SSH_AUTH_SOCK`
- `SSH_AGENT_PID`
- `SSH_CONNECTION`
- `WINDOWID`
- `XAUTHORITY`
- `KITTY_LISTEN_ON`
- `KITTY_PID`
- `KITTY_WINDOW_ID`

You can customize this list by setting `ZMX_TRACK_ENV` to a comma-separated list of variable names:

```bash
export ZMX_TRACK_ENV="DISPLAY,SSH_AUTH_SOCK,GPG_AGENT_INFO"
```

## shell completion

Shell auto-completion for `zmx` commands and session names can be enabled using the `completions` subcommand. Once configured, you'll get auto-complete for both local `zmx` commands and sessions:

```bash
ssh remote-server zmx attach session-na<TAB>
# <- auto-complete suggestions appear here
```

> NOTICE: when installing `zmx` with `homebrew` completions are automatically installed.

### bash

Add this to your `.bashrc` file:

```bash
if command -v zmx &> /dev/null; then
  eval "$(zmx completions bash)"
fi
```

### zsh

Add this to your `.zshrc` file:

```zsh
if command -v zmx &> /dev/null; then
  eval "$(zmx completions zsh)"
fi
```

### fish

Add this to `~/.config/fish/completions/zmx.fish`:

```fish
if type -q zmx
  zmx completions fish | source
end
```

### yash

Add this to your `~/.config/yash/rc`:

```sh
if command -v zmx > /dev/null 2>&1; then
  eval "$(zmx completions yash)"
fi
```

Or save as an autoloaded script in your completion directory:

```sh
zmx completions yash > ~/.config/yash/completion/zmx
```

### nu

Add this to your Nushell config (`config.nu`):

```nu
use ("~/.cache/zmx/completions.nu" | path expand)
# Or generate dynamically:
zmx completions nu | save -f ~/.cache/zmx/completions.nu
```

## session picker

You can add an interactive session picker to your shell that lets you fuzzy-find existing sessions, preview their scrollback history, or create new ones -- all from a single prompt. This is especially useful for remote SSH workflows: add it to your shell startup so that connecting to a machine immediately presents the picker.

Requires [fzf](https://github.com/junegunn/fzf).

- **Enter** selects a matched session (or creates one if no sessions exist)
- **Ctrl-N** creates a new session using the typed query, even when a fuzzy match is highlighted

<details>
<summary>bash and zsh</summary>

```bash
zmx-select() {
  local display
  local prefix="${ZMX_SESSION_PREFIX:-}"
  display=$(zmx list 2>/dev/null | while IFS=$'\t' read -r name pid clients created dir; do
    name=${name#*name=}
    pid=${pid#*pid=}
    clients=${clients#*clients=}
    dir=${dir#*start_dir=}
    if [[ -n "$prefix" ]]; then
      [[ "$name" == "$prefix"* ]] || continue
      name=${name#"$prefix"}
    fi
    printf "%-20s  pid:%-8s  clients:%-2s  %s\n" "$name" "$pid" "$clients" "$dir"
  done)

  local output query key selected session_name
  output=$({ [[ -n "$display" ]] && echo "$display"; } | fzf \
    --print-query \
    --expect=ctrl-n \
    --height=80% \
    --reverse \
    --prompt="zmx> " \
    --header="Enter: select | Ctrl-N: create new" \
    --preview='zmx history {1}' \
    --preview-window=right:60%:follow \
  )
  local rc=$?

  query=$(echo "$output" | sed -n '1p')
  key=$(echo "$output" | sed -n '2p')
  selected=$(echo "$output" | sed -n '3p')

  if [[ "$key" == "ctrl-n" && -n "$query" ]]; then
    session_name="$query"
  elif [[ $rc -eq 0 && -n "$selected" ]]; then
    session_name=$(echo "$selected" | awk '{print $1}')
  elif [[ -n "$query" ]]; then
    session_name="$query"
  else
    return 130
  fi

  zmx attach "$session_name"
}
```

You can call `zmx-select` manually, bind it to a key, or auto-launch it on shell startup when outside a zmx session. With `&& exit`, the normal flow becomes: connect via SSH → pick a session → work → detach or exit the session → SSH disconnects automatically. Cancelling the picker with **Ctrl-C** drops you into a regular shell as an escape hatch.

```bash
if command -v zmx &> /dev/null && command -v fzf &> /dev/null && [[ -z "$ZMX_SESSION" ]]; then
  zmx-select && exit
fi
```

#### Alternative: gentle hint (server use)

If you use zmx on a shared server and SSH in frequently for quick operations, auto-launching the picker on every connection may be too aggressive. Instead, show a one-line reminder when active sessions exist:

```bash
if command -v zmx &> /dev/null && [[ -z "$ZMX_SESSION" ]]; then
  local count
  count=$(zmx ls --short 2>/dev/null | wc -l)
  if [[ "$count" -gt 0 ]]; then
    echo "zmx: $count session(s) active — \`zmx-select\` to attach" >&2
  fi
fi
```

Choose the auto-launch pattern for dedicated dev machines, and the hint pattern for shared servers where you frequently run quick commands.

</details>

## session prefix

We allow users to set an environment variable `ZMX_SESSION_PREFIX` which will prefix the name of the session for all commands. This means if that variable is set, every command that accepts a session will be prefixed with it.

```bash
export ZMX_SESSION_PREFIX="d."
zmx a runner # ZMX_SESSION=d.runner
zmx a tests  # ZMX_SESSION=d.tests
zmx k tests  # kills d.tests
zmx wait     # suspends until all tasks prefixed with "d." are complete
```

## philosophy

The entire argument for `zmx` instead of something like `tmux` that has windows, panes, splits, etc. is that job should be handled by your os window manager. By using something like `tmux` you now have redundant functionality in your dev stack: a window manager for your os and a window manager for your terminal. Further, in order to use modern terminal features, your terminal emulator **and** `tmux` need to have support for them. This holds back the terminal enthusiast community and feature development.

Instead, this tool specifically focuses on session persistence and defers window management to your os wm.

## ssh workflow

### Try it out quickly

If you'd like to try out `zmx` and `ssh` without fiddling your `ssh` config, make sure to pass the `-t` option to `ssh`. Here's an example:

```bash
ssh -t dev-box zmx attach default
```

Without `-t`, the remote shell will not know it's talking to a terminal, and the display will likely get messed up.

This option isn't needed if you follow the configuration steps below, because `RequestTTY yes` does the same thing.

### Configure it for regular use

Using `zmx` with `ssh` is a first-class citizen. Instead of using `ssh` to remote into your system with a single terminal and `n` tmux panes, you open `n` terminals and run `ssh` for all of them. This might sound tedious, but there are tools to make this a delightful workflow.

First, create an `ssh` config entry for your remote dev server:

```bash
Host = d.*
    HostName 192.168.1.xxx

    RemoteCommand zmx attach %k
    RequestTTY yes
    ControlPath ~/.ssh/cm-%r@%h:%p
    ControlMaster auto
    ControlPersist 10m
```

Architecturally, `ssh` supports multiplexing multiple channels of communication within a single connection to a server. `ControlMaster` is the setting that tells `ssh` to multiplex multiple PTY sessions to a single server over one tcp connection. Neat!

Now you can spawn as many terminal sessions as you'd like:

```bash
ssh d.term
ssh d.irc
ssh d.pico
ssh d.dotfiles
```

Because the `attach` command is essentially an "upsert", this will create or attach to each session.

Now you can use the [`autossh`](https://linux.die.net/man/1/autossh) tool to make your ssh connections auto-reconnect. For example, if you have a laptop and close/open your lid it will automatically reconnect all your ssh connections:

```bash
autossh -M 0 -q d.term
```

Or create an `alias`/`abbr`:

```fish
abbr -a ash "autossh -M 0 -q"
```

```bash
ash d.term
ash d.irc
ash d.pico
ash d.dotifles
```

Wow! Now you can setup all your os tiling windows how you like them for your project and have as many windows as you'd like, almost replicating exactly what `tmux` does but with native windows, tabs, splits, and scrollback! It also has the added benefit of supporting all the terminal features your emulator supports, no longer restricted by what `tmux` supports.

The end-game here would be to leverage your window manager's ability to automatically arrange your windows for each project with a single command.

## socket file location

Each session gets its own unix socket file. The default location depends on your environment variables (checked in priority order):

1. `ZMX_DIR` => uses exact path (e.g., `/custom/path`)
1. `XDG_RUNTIME_DIR` => uses `{XDG_RUNTIME_DIR}/zmx` (recommended on Linux, typically results in `/run/user/{uid}/zmx`)
1. `TMPDIR` => uses `{TMPDIR}/zmx-{uid}` (appends uid for multi-user safety)
1. `/tmp` => uses `/tmp/zmx-{uid}` (default fallback, appends uid for multi-user safety)

## permissions

You can configure the permissions for the socket directory and log files using the following environment variables:

- `ZMX_DIR_MODE` => sets the mode for the socket and log directories (octal, defaults to `0750`)
- `ZMX_LOG_MODE` => sets the mode for the log files (octal, defaults to `0640`)

This is particularly useful when running `zmx` as a system service with a shared group. For example, setting `ZMX_DIR_MODE=0770` and `ZMX_LOG_MODE=0660` allows group members to attach to the session.

## debugging

We store global logs for cli commands in `{log_dir}/zmx.log`. We store session-specific logs in `{log_dir}/{session_name}.log`. Right now they are enabled by default and cannot be disabled. The idea here is to help with initial development until we reach a stable state.

The log directory is resolved in this order:

1. `ZMX_DIR/logs` if `ZMX_DIR` is set
1. `XDG_STATE_HOME/zmx/logs` if `XDG_STATE_HOME` is set
1. `HOME/.local/state/zmx/logs`
1. `TMPDIR/zmx-$UID` (or `/tmp/zmx-$UID`) as a last resort

## Ghostex private OSC sequences and `zmx grid`

This fork carries Ghostex-only behavior layered on the attach protocol. An
attach client consumes these in-band sequences from its stdin (they are never
forwarded to the pty) and turns them into IPC messages; the canonical parser is
`appendClientInputMessages` in `src/loop.zig`.

- `ESC ] 1337 ; ZMX_REFRESH BEL`: repaint this client; leadership-neutral.
- `ESC ] 1337 ; ZMX_VISIBLE=<rows>,<cols> BEL`: terminal on screen at this size.
- `ESC ] 1337 ; ZMX_CHAT=<rows>,<cols> BEL`: chat on screen, claiming a wide resting grid.
- `ESC ] 1337 ; ZMX_HIDDEN=<rows>,<cols> BEL`: parked for any other reason, no chat claim.

Only a visible terminal may size the PTY, with the most recently active client
winning. A fresh attach and user input count as visible. With no visible client,
a chat claim widens the grid to at least `RESTING_GRID_COLS` (200), using the
freshest parked client's rows. Without either claim, the grid stays unchanged.
Dropping a chat claim never narrows an unattended grid. Headless sessions start
at 50x200. Background or non-selected chat tabs hold no claim.

Both non-visible states pin their local emulator to 200 columns because another
client's chat claim may widen the daemon. Once visibility is announced, all
subsequent grid changes must use visibility OSCs; bare SIGWINCH/Resize is ignored
for that client so local parking cannot race ahead and widen the shared PTY.
Plain attach clients continue to size through SIGWINCH. `zmx send` never changes leadership.
`zmx grid <name>` prints the grid, leader, resting size, `chat_claim`, and each
client's `state` (`visible`, `chat`, `parked`) as JSON.

## a smol contract

- Write programs that solve a well defined problem.
- Write programs that behave the way most users expect them to behave.
- Write programs that a single person can maintain.
- Write programs that compose with other smol tools.
- Write programs that can be finished.

## known issues

- When upgrading versions of `zmx` where we make changes to the underlying IPC communication, it will kill all your sessions because it cannot communicate through the daemon socket properly
- Terminal state restoration with nested `zmx` sessions through SSH: host A `zmx` -> SSH -> host B `zmx`
  - Specifically cursor position gets corrupted
  - Essentially this is unspecified and unsupported behavior
- When re-attaching and kitty keyboard mode was previously enable, we try to re-send that CSI query to re-enable it
  - Some programs don't know how to handle that CSI query (e.g. `psql`) so when you type it echos kitty escape sequences erroneously

## impl

- The `daemon` and client processes communicate via a unix socket
- Both `daemon` and `client` loops leverage `poll(2)`
- Each session creates its own unix socket file
- We restore terminal state and output using `libghostty-vt`

### libghostty-vt

We use `libghostty-vt` to restore the previous state of the terminal when a client re-attaches to a session.

How it works:

- user creates session `zmx attach term`
- user interacts with terminal stdin
- stdin gets sent to pty via daemon
- daemon sends pty output to client *and* `ghostty-vt`
- `ghostty-vt` holds terminal state and scrollback
- user disconnects
- user re-attaches to session
- `ghostty-vt` sends terminal snapshot to client stdout

In this way, `ghostty-vt` doesn't sit in the middle of an active terminal session, it simply receives all the same data the client receives so it can re-hydrate clients that connect to the session. This enables users to pick up where they left off as if they didn't disconnect from the terminal session at all. It also has the added benefit of being very fast, the only thing sitting in-between you and your PTY is a unix socket.

## prior art

Below is a list of projects that inspired me to build this project. Architecturally, `zmx` uses aspects of both projects. For example, `shpool` inspired the idea of having libghostty restore the terminal state on reattach. Abduco inspired the idea of one daemon (and unix socket) per session.

### shpool

https://github.com/shell-pool/shpool

`shpool` is a service that enables session persistence by allowing the creation of named shell sessions owned by `shpool` so that the session is not lost if the connection drops.

### abduco

https://github.com/martanne/abduco

abduco provides session management (i.e. it allows programs to be run independently from its controlling terminal). Together with dvtm it provides a simpler alternative to tmux or screen.

## comparison

| Feature                        | zmx | shpool | abduco | dtach | tmux |
| ------------------------------ | --- | ------ | ------ | ----- | ---- |
| 1:1 Terminal emulator features | ✓   | ✓      | ✓      | ✓     | ✗    |
| Terminal state restore         | ✓   | ✓      | ✗      | ✗     | ✓    |
| Window management              | ✗   | ✗      | ✗      | ✗     | ✓    |
| Multiple clients per session   | ✓   | ✗      | ✓      | ✓     | ✓    |
| Native scrollback              | ✓   | ✓      | ✓      | ✓     | ✗    |
| Configurable detach key        | ✗   | ✓      | ✓      | ✓     | ✓    |
| Auto-daemonize                 | ✓   | ✓      | ✓      | ✓     | ✓    |
| Daemon per session             | ✓   | ✗      | ✓      | ✓     | ✗    |
| Session listing                | ✓   | ✓      | ✓      | ✗     | ✓    |

## community tools

- [emacs-term-sessions](https://github.com/ArthurHeymans/emacs-term-sessions) Persistent terminal sessions in Emacs, both local and remote.
- [pi-zmx](https://github.com/deevus/pi-zmx) -- [pi](https://pi.dev) extension for zmx.
- [zsm](https://github.com/mdsakalu/zmx-session-manager) -- TUI session manager for zmx. List, preview, filter, and kill sessions from an interactive terminal UI.
- [zmosh](https://github.com/mmonad/zmosh) -- A fork of zmx that adds encrypted UDP auto-reconnect for remote sessions (like mosh).
- [zmx-picker](https://github.com/EarthmanMuons/zmx-picker) -- fzf-based session picker and project launcher. Jump to a running zmx session or start one inside any of your git/jj repos.
- [rootshell](https://github.com/kitknox/rootshell) -- Metal-accelerated terminal for iPhone, iPad, Vision Pro, and Mac. Lists active zmx sessions with live previews and can auto-attach on connect.
