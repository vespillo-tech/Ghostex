# Draft: Restore static Kitty images and coordinate optional viewer grid changes

**Target: maddada/zmx `nightly`; base feaefff987232ed4628873eb6154813ea760f284.** This is the daemon revision pinned by Ghostex. The repository's `main` branch is a different, older baseline.

## Why

Live Kitty commands already pass through zmx. Snapshots retained styled cells without image pixels or placements; PNG state also lacked a registered decoder. Fresh viewers lost images, and refresh's ED2 deleted ordinary placements. A second reproduction showed an ordinary image drifting six columns when a viewer resized before the daemon while intervening output overwrote wrapped cells. Text repaint alone could not repair that image pin.

## Implementation and review map

- `build.zig`/`main.zig`: register Ghostty's already-pinned Wuffs decoder before terminal creation. Reuse its deployment configuration and validate input/dimensions before decode; add no dependency.
- `kitty_replay.zig`: borrow retained state synchronously; no raw escape-history cache. Upload selected explicit-ID static assets once in 4096-byte base64 chunks with `q=2`. Reconstruct ordinary history pins while addressable and active ordinary/virtual placements after the grid. Preserve external IDs and semantic order; the receiver assigns internal IDs.
- `util.zig`: neutral coordinates for content; set/clear mode 2027 before any history/grid; restore modes, margins, cursor and pending wrap afterward. Restore primary behind active alternate without clearing freshly loaded assets. Preserve wide-cell and soft-wrap history boundaries while keeping short hard rows trimmed. Refresh uses ED0, emits no graphics and preserves an already-open program synchronized update.
- `ipc.zig`/`loop.zig`: optional empty `GridSync` tag 210 before unchanged Init; daemon queues authoritative grid/pixels at its resize mutation before later output. Initial attachment gets one baseline even without output. A single normalized-size comparison prevents false changes; unchanged claims send no grid record or repaint. Existing automatic refresh follows actual transitions.
- `main.zig`/`loop.zig`: attach-scoped nonce from the stable environment map, scrubbed before daemon/program creation and from tracked variables. The attach client writes fixed records and start/exit resets; Ghostex removes them outside its VT parser. Output queue failure closes the affected ordered replica instead of allowing missing bytes or unwinding the daemon's output handler.

## Compatibility

Existing IPC tags/payloads and wire generation **2** are unchanged. Old daemons ignore the additive advertisement, serve ordinary Init and leave the host on its existing resize/refresh path. Non-advertising clients receive no records. Existing old daemons gain replay when naturally replaced; this proposal forces no session restart.

Ordered coordination is verified on local POSIX Agents/zmx viewers. The opt-in condition also includes SSH viewers, but normal SSH does not forward the attach nonce and therefore uses immediate resize; nonce forwarding and remote ordered coordination remain unverified. Older/non-advertising daemons and browser/mobile/wmx clients retain their existing path. Native Windows wmx's vt100 parser retains no Kitty or program synchronized-output state; the public review archive includes a README scope patch explaining the retained-state gap; it is documentation only and does not implement native Windows graphics.

## Resource and restoration contract

Replay: 16 MiB decoded bytes per screen, 4096 per side, 4 Mi pixels per image and 4096 eligible assets/placements. Entry overflow omits that screen's graphics; byte-budget selection prefers visible/virtual assets, then history, then unplaced assets. Static explicit-ID RGB/RGBA/decoded PNG, ordinary/virtual/mixed/unplaced/history state is supported.

Animation, relative replay, pending transfers, number aliases (`I=`) and implicit identities are excluded. Existing snapshots do not reconstruct inactive alternate storage or arbitrary saved cursor slots. Histories printed under differing mode-2027 settings replay under the final global mode: text can match while historical cell widths differ. This was reproduced on both exact base and candidate and is a separate follow-up. A controlled partial UTF-8 prefix delivered before Init leaves an extra replacement character on both revisions; it is a separate attachment-order issue. The bounded incomplete CSI/OSC/Kitty prefixes had matching visible grids; pending-transfer completion is not covered.

The zmx decoder rejects PNG encoded input above 16 MiB after buffering. This daemon limit is separate from the renderer's 40 MiB encoded-input limit; the renderer audit did not change zmx, and retained replay of PNGs above the daemon limit remains a known gap. The inherited 400 MiB transfer/decompression ceiling and raw storage/permission policy are unchanged. Decoded limits do not bound aggregate memory. Rejected PNGs still pass through live; omitted/rejected retained assets may need application redraw.

## Validation

On Apple Silicon macOS: current ReleaseSafe build passed (43/43 steps); existing Debug suite passed **108/108**. An external pinned-core harness passed **39** semantic cases comparing pixels, placements, active cursor, retained text/history, wrap flags and grapheme mode; each also checks 50 graphics-free refreshes and nested attach. Separate checks cover prompt-redraw preservation and synchronized output on/off.

Actual native-reader PTY checks cover six quiet/append/overwrite reflow cases plus pixel-only resizing. Legacy overwrite drifts; coordinated mode matches. Real PTYs verified raw/PNG attachment, zero graphics on refresh, 4096/4097 placement boundaries, absent nonce in new session programs/tracked environment, output-less Init and new client/old daemon fallback. Three fractional-pixel no-op claims changed from three repaints/records to zero.

The earlier optimized isolated Ghostex app displayed both image forms through search, splitting, native window resize, history and fresh viewer attachment without fixture redraw. Same-ID panes stayed independent; the tiny-source replacement remained solid green. Only macOS arm64 runtime acceptance is claimed. The renderer’s full Debug lib-vt gate passed 6,472 tests with 52 skips, across both roots.

Actual Opus 5.5 `xhigh` reviews covered source and corrections; findings were independently resolved, including review-requested failure-path and platform cfg checks. Patch replay reproduces exactly seven scoped files. External probes are review artifacts, not new repository tests.

Integrate with the [companion Ghostex renderer](https://github.com/maddada/Ghostex/pull/186) and its exact reviewed dependency pin. Review head: `ff399831abdc33e55c9841d324ff3bc70cfd7115` on `vespillo-tech:contrib/static-kitty-replay`, directly based on the nightly revision above.

## Renderer maintainer follow-up — 2026-10-04

The follow-up to the original replay candidate adds only two CDXC:Zmx SEE-ALSO comment lines at `clientLoop`'s GridSync emitter, naming Ghostex's decoder and the shared nonce/hex/APC framing. Matching comments are in the renderer. No daemon, wire, tag or replay behavior changes, so the existing tests remain historical evidence for identical executable code. Scoped formatting and actual Opus 5.5 `xhigh` follow-up review passed. The current archive includes `zmx-current-review.patch`; the original candidate patch remains for traceability. Keep this draft and the renderer coordinated; the exact reviewed upstream feature pin and combined checks gate release.

## Review evidence

[Portable fixtures, probes, full validation logs and checked review findings](https://github.com/vespillo-tech/Ghostex/blob/review/static-kitty-images/README.md). The archive includes the seven-file zmx patch and documented known limitations.
