#!/usr/bin/env python3
"""Exercise the actual VT image bridge with public, generated boundary fixtures.

Usage: renderer-boundary-probe.py RENDERER_CHECKOUT LIB_DIRECTORY
       [--module-source PATH] [--expect-original-defects]
Requires Rust1.95 release image/libc libraries from RENDERER_CHECKOUT.
No app, settings, network, or repository tests. Temporary PNGs are generated
with the standard library. Baseline mode asserts all three original defects;
candidate mode checks offsets, live relative chains, layers, culling and PNGs.
The full-pixel PNG overhead case raises only its disposable source budget to
64 MiB. Ordinary production source storage remains 10,000,000 bytes.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, struct, subprocess, tempfile, zlib

RUST = r'''
#![allow(dead_code,unused_imports)]
#[path=__MODULE__] mod ghostty_vt;
use ghostty_vt::*;
fn image(t:&mut VtTerminal,id:u32,options:&str){
 t.feed(format!("\x1b_Ga=T,f=32,i={id},p=1,s=1,v=1,C=1,q=2,{options};/wAA/w==\x1b\\").as_bytes());
}
fn placeholder(t:&mut VtTerminal,row:u16,col:u16){
 t.feed(format!("\x1b[{row};{col}H\x1b[38;2;0;0;52m\u{10eeee}\u{305}\u{305}\x1b[0m").as_bytes());
}
fn relative(t:&mut VtTerminal,id:u32,parent:u32,h:i32,v:i32,cols:u16,rows:u16,z:i32){
 image(t,id,&format!("c={cols},r={rows},P={parent},Q=1,H={h},V={v},z={z}"));
}
fn encode64(bytes:&[u8])->String{
 const TABLE:&[u8;64]=b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 let mut out=Vec::with_capacity(bytes.len().div_ceil(3)*4);
 for c in bytes.chunks(3){let a=c[0];let b=c.get(1).copied().unwrap_or(0);let d=c.get(2).copied().unwrap_or(0);
  out.push(TABLE[(a>>2)as usize]);out.push(TABLE[(((a&3)<<4)|(b>>4))as usize]);
  out.push(if c.len()>1 {TABLE[(((b&15)<<2)|(d>>6))as usize]}else{b'='});
  out.push(if c.len()>2 {TABLE[(d&63)as usize]}else{b'='});}
 String::from_utf8(out).unwrap()
}
fn png(t:&mut VtTerminal,id:u32,bytes:&[u8]){
 let encoded=encode64(bytes);let chunks:Vec<_>=encoded.as_bytes().chunks(4096).collect();
 for (n,chunk) in chunks.iter().enumerate(){
  let more=u8::from(n+1<chunks.len());let header=if n==0 {format!("a=T,f=100,i={id},c=1,r=1,C=1,q=2,m={more}")} else {format!("q=2,m={more}")};
  let mut cmd=format!("\x1b_G{header};").into_bytes();cmd.extend_from_slice(chunk);cmd.extend_from_slice(b"\x1b\\");t.feed(&cmd);
 }
}
fn main()->Result<(),Box<dyn std::error::Error>>{
 let args:Vec<_>=std::env::args().collect();let old=args.iter().any(|x|x=="original");
 let mut t=VtTerminal::new(8,6,1024)?;t.resize(8,6,20,20)?;
 image(&mut t,1,"c=1,r=1,X=19,Y=19");let before=t.image_placements()?;
 assert_eq!((before[0].offset_x,before[0].offset_y,before[0].width,before[0].height),(19,19,1,1));
 t.resize(8,6,10,10)?;let after=t.image_placements()?;
 assert_eq!((after[0].offset_x,after[0].offset_y),if old{(19,19)}else{(9,9)});
 assert_eq!((after[0].width,after[0].height),(1,1));assert_eq!(before[0].offset_x,19);
 println!("PASS cell-shrink offsets={} prior-frame geometry retained",if old{"original defect19"}else{"resolved9"});
 if !old {
  t.resize(8,6,0,0)?;let zero=t.image_placements()?;
  assert!(zero.is_empty()||zero.iter().all(|p|p.offset_x==0&&p.offset_y==0));
  t.resize(8,6,20,20)?;let restored=t.image_placements()?;assert_eq!((restored[0].offset_x,restored[0].offset_y),(19,19));
  println!("PASS unknown geometry and restored cell dimensions");
 }
 t.reset();t.resize(8,6,10,10)?;image(&mut t,52,"c=1,r=1,U=1");placeholder(&mut t,1,1);
 relative(&mut t,53,52,1,0,1,1,7);let frame=t.image_placements()?;
 assert_eq!(frame.iter().any(|p|p.image.id==53),!old);
 println!("PASS virtual-root ordinary child {}",if old{"originally missing"}else{"visible"});
 if !old {
  let child=frame.iter().find(|p|p.image.id==53).unwrap();assert_eq!((child.col,child.row,child.width,child.height,child.z),(1,0,10,10,7));
  assert!(frame.iter().filter(|p|p.image.id==52).all(|p|p.z==-1));
  relative(&mut t,54,53,1,1,1,1,-7);
  relative(&mut t,55,52,-1,0,2,1,-3);
  relative(&mut t,56,52,-3,0,1,1,0);
  relative(&mut t,57,52,8,0,1,1,0);
  relative(&mut t,58,52,0,-1,1,2,0);
  let frame=t.image_placements()?;
  let nested=frame.iter().find(|p|p.image.id==54).unwrap();assert_eq!((nested.col,nested.row,nested.z),(2,1,-7));
  let left=frame.iter().find(|p|p.image.id==55).unwrap();assert_eq!((left.col,left.row,left.width),(-1,0,20));
  let above=frame.iter().find(|p|p.image.id==58).unwrap();assert_eq!((above.col,above.row,above.height),(0,-1,20));
  assert!(!frame.iter().any(|p|p.image.id==56||p.image.id==57));
  println!("PASS nested chains signed edges offscreen culling and own z layers");
  t.feed(b"\x1b[2J");assert!(t.image_placements()?.is_empty());
  placeholder(&mut t,2,4);placeholder(&mut t,4,2);
  let frame=t.image_placements()?;let child=frame.iter().find(|p|p.image.id==53).unwrap();
  assert_eq!((child.col,child.row),(2,1));
  println!("PASS absent-placeholder hiding and minimum visible-root coordinates");
  t.feed(b"\x1b_Ga=d,d=i,i=52,q=2\x1b\\");assert!(!t.image_placements()?.iter().any(|p|p.image.id==53||p.image.id==54));
  println!("PASS deleted parent does not leave live descendants");
 }
 let mut expected=None;
 for (n,path) in args[1..3].iter().enumerate(){
  let bytes=std::fs::read(path)?;let mut reader=image::ImageReader::with_format(std::io::Cursor::new(&bytes),image::ImageFormat::Png);
  let mut limits=image::Limits::default();limits.max_image_width=Some(4096);limits.max_image_height=Some(4096);limits.max_alloc=Some(32*1024*1024);reader.limits(limits);
  let pixels=image::DynamicImage::from_decoder(reader.into_decoder()?)?.into_rgba8();
  assert_eq!(pixels.len(),9_000_000);if let Some(e)=&expected {assert_eq!(pixels.as_raw(),e)}else{expected=Some(pixels.as_raw().clone())};
  t.reset();t.resize(8,6,10,10)?;png(&mut t,70,&bytes);let frame=t.image_placements()?;
  let rejected=old&&n==0;assert_eq!(frame.len(),usize::from(!rejected));
  if !rejected{assert_eq!(frame[0].image.rgba,pixels.as_raw().as_slice())};
  println!("PASS RGBA16 PNG encoded={} decoded={} retained={} default-source-budget=10000000",bytes.len(),pixels.len(),frame.len());
 }
 t.reset();t.probe_source_storage(64*1024*1024)?;t.resize(8,6,10,10)?;
 let bytes=std::fs::read(&args[3])?;
 png(&mut t,71,&bytes);let frame=t.image_placements()?;
 assert_eq!(frame.len(),usize::from(!old));
 if !old {assert_eq!(frame[0].image.rgba.len(),16*1024*1024);}
 println!("PASS full-pixel RGBA16 encoded={} retained={} source-storage-scope=disposable64MiB",bytes.len(),frame.len());
 println!("result={}",if old{"EXPECTED_ORIGINAL_THREE_DEFECTS"}else{"PASS"});Ok(())
}
'''

def chunk(kind,data):
    return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)

def make_png(level,side=1500):
    row=b'\0'+struct.pack('>4H',65535,32768,257,65535)*side
    return (b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>2I5B',side,side,16,6,0,0,0))
            +chunk(b'IDAT',zlib.compress(row*side,level))+chunk(b'IEND',b''))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('renderer',type=Path);p.add_argument('library',type=Path)
    p.add_argument('--module-source',type=Path);p.add_argument('--expect-original-defects',action='store_true')
    a=p.parse_args();renderer=a.renderer.resolve();library=a.library.resolve()
    module=(a.module_source or renderer/'apps/desktop/src/ghostty_vt').resolve()
    deps=renderer/'apps/desktop/target/release/deps'
    print('module_images_sha256='+hashlib.sha256((module/'images.rs').read_bytes()).hexdigest(),flush=True)
    print('module_ffi_sha256='+hashlib.sha256((module/'ffi.rs').read_bytes()).hexdigest(),flush=True)
    print('native_archive_sha256='+hashlib.sha256((library/'libghostty-vt.a').read_bytes()).hexdigest(),flush=True)
    with tempfile.TemporaryDirectory(prefix='gx-renderer-boundaries-') as td:
        out=Path(td);copied=out/'ghostty_vt';shutil.copytree(module,copied)
        terminal=copied/'terminal.rs'
        terminal.write_text(terminal.read_text()+'''
impl VtTerminal {
 pub(crate) fn probe_source_storage(&mut self,bytes:u64)->Result<(),VtError>{
  check(unsafe{ffi::ghostty_terminal_set(self.raw,15,std::ptr::from_ref(&bytes).cast())})
 }
}
''')
        rs=out/'probe.rs';rs.write_text(RUST.replace('__MODULE__',json.dumps(str(copied/'mod.rs'))))
        binary=out/'probe';cmd=['rustc','+1.95.0','--edition=2024','-O',str(rs),'-o',str(binary),'-L','dependency='+str(deps),'-L','native='+str(library),'-lstatic=ghostty-vt','-lc++']
        for name in ['image','libc']:cmd+=['--extern',name+'='+str(sorted(deps.glob('lib'+name+'-*.rlib'))[0])]
        subprocess.run(cmd,check=True)
        paths=[]
        for level in [0,9]:
            path=out/f'rgba16-{level}.png';path.write_bytes(make_png(level));paths.append(str(path))
        path=out/'rgba16-full-pixel.png';path.write_bytes(make_png(0,2048));paths.append(str(path))
        subprocess.run([str(binary),*paths,*(['original'] if a.expect_original_defects else [])],check=True,timeout=45)

if __name__=='__main__':main()
