#!/usr/bin/env python3
"""Compare actual compiled ABI descriptors with C headers and Rust bindings.
Usage: abi-probe.py RENDERER_CHECKOUT LIB_DIRECTORY
No app or repository edits. Requires cc, Rust1.95 and the native archive.
"""
from pathlib import Path
import argparse,json,subprocess,tempfile,hashlib

p=argparse.ArgumentParser(description=__doc__);p.add_argument('renderer',type=Path);p.add_argument('library',type=Path);a=p.parse_args()
r=a.renderer.resolve();lib=a.library.resolve()
with tempfile.TemporaryDirectory(prefix='gx-image-abi-') as td:
    out=Path(td);c=out/'probe.c';binary=out/'probe'
    c.write_text('''#include <ghostty/vt.h>
#include <stdio.h>
#include <stddef.h>
int main(void) {
 printf("{\\"info_size\\":%zu,\\"info_x\\":%zu,\\"info_y\\":%zu,\\"virtual_size\\":%zu,\\"virtual_col\\":%zu,\\"virtual_row\\":%zu,\\"virtual_z\\":%zu}\\n",
 sizeof(GhosttyKittyGraphicsPlacementRenderInfo),offsetof(GhosttyKittyGraphicsPlacementRenderInfo,offset_x),offsetof(GhosttyKittyGraphicsPlacementRenderInfo,offset_y),
 sizeof(GhosttyKittyGraphicsVirtualPlacement),offsetof(GhosttyKittyGraphicsVirtualPlacement,viewport_col),offsetof(GhosttyKittyGraphicsVirtualPlacement,viewport_row),offsetof(GhosttyKittyGraphicsVirtualPlacement,z));
 puts(ghostty_type_json());
}
''')
    subprocess.run(['cc',str(c),'-I'+str(r/'.dependencies/ghostty/include'),str(lib/'libghostty-vt.a'),'-lc++','-o',str(binary)],check=True)
    result=subprocess.check_output([str(binary)],text=True).splitlines()
    header=json.loads(result[0]);manifest=json.loads('\n'.join(result[1:]));types=manifest['types']
    if isinstance(types,list):types={x['name']:x for x in types}
    selected={name:types[name] for name in ['GhosttyKittyGraphicsPlacementRenderInfo','GhosttyKittyGraphicsVirtualPlacement']}
    rs=out/'rust.rs';rb=out/'rust'
    rs.write_text('''#![allow(dead_code)]
#[path=__FFI__] mod ffi;
use std::mem::{size_of,offset_of};
fn main(){println!("{},{},{},{},{},{},{}",size_of::<ffi::GhosttyKittyGraphicsPlacementRenderInfo>(),offset_of!(ffi::GhosttyKittyGraphicsPlacementRenderInfo,offset_x),offset_of!(ffi::GhosttyKittyGraphicsPlacementRenderInfo,offset_y),size_of::<ffi::GhosttyKittyGraphicsVirtualPlacement>(),offset_of!(ffi::GhosttyKittyGraphicsVirtualPlacement,viewport_col),offset_of!(ffi::GhosttyKittyGraphicsVirtualPlacement,viewport_row),offset_of!(ffi::GhosttyKittyGraphicsVirtualPlacement,z));}
'''.replace('__FFI__',json.dumps(str(r/'apps/desktop/src/ghostty_vt/ffi.rs'))))
    subprocess.run(['rustc','+1.95.0','--edition=2024',str(rs),'-o',str(rb)],check=True)
    rust=list(map(int,subprocess.check_output([str(rb)],text=True).strip().split(',')))
    assert rust==list(header.values()),(rust,header)
    assert header==dict(info_size=64,info_x=52,info_y=56,virtual_size=80,virtual_col=12,virtual_row=16,virtual_z=72)
    info=selected['GhosttyKittyGraphicsPlacementRenderInfo'];virtual=selected['GhosttyKittyGraphicsVirtualPlacement']
    assert info['size']==header['info_size'] and virtual['size']==header['virtual_size']
    for field,key in [('offset_x','info_x'),('offset_y','info_y')]:
        assert info['fields'][field]['offset']==header[key] and info['fields'][field]['type']=='u32'
    for field,key in [('viewport_col','virtual_col'),('viewport_row','virtual_row'),('z','virtual_z')]:
        assert virtual['fields'][field]['offset']==header[key] and virtual['fields'][field]['type']=='i32'
    print(json.dumps({'native_archive_sha256':hashlib.sha256((lib/'libghostty-vt.a').read_bytes()).hexdigest(),'headers_rust_and_compiled_descriptors_agree':True,'header_layout':header,'compiled_descriptors':selected},indent=2))
