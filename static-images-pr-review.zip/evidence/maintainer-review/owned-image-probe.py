#!/usr/bin/env python3
"""Exercise production native Kitty image ownership in an isolated build.

Usage: owned-image-probe.py RENDERER_CHECKOUT LIB_DIRECTORY
         [--baseline-image-source PATH] [--expect-unbounded]

Requires the checkout's Rust toolchain, locally cached image dependencies, and
libghostty-vt.a in LIB_DIRECTORY. Copies the production ghostty_vt module;
only module visibility and read-only cache inspection are added to that copy.
The byte-budget scenario raises the disposable terminal's source storage to
64 MiB through native option 15. Normal production source storage is 10 MB.
This checks cache ownership; prior frame Arcs may retain additional pixels.
"""

import argparse
import hashlib
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


RUST_MAIN = r'''
#![allow(dead_code)]
mod ghostty_vt;
use ghostty_vt::{ffi, VtImagePlacement, VtTerminal};
use std::{collections::HashSet, sync::Arc};

const MIB: usize = 1024 * 1024;
const CAP: usize = 64 * MIB;

fn encode64(bytes: &[u8]) -> String {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = Vec::with_capacity(bytes.len().div_ceil(3) * 4);
    for chunk in bytes.chunks(3) {
        let a = chunk[0];
        let b = chunk.get(1).copied().unwrap_or(0);
        let c = chunk.get(2).copied().unwrap_or(0);
        out.push(TABLE[(a >> 2) as usize]);
        out.push(TABLE[(((a & 3) << 4) | (b >> 4)) as usize]);
        out.push(if chunk.len() > 1 { TABLE[(((b & 15) << 2) | (c >> 6)) as usize] } else { b'=' });
        out.push(if chunk.len() > 2 { TABLE[(c & 63) as usize] } else { b'=' });
    }
    String::from_utf8(out).unwrap()
}

fn command(terminal: &mut VtTerminal, header: &str, payload: &[u8]) {
    let mut bytes = format!("\x1b_G{header};").into_bytes();
    bytes.extend_from_slice(payload);
    bytes.extend_from_slice(b"\x1b\\");
    terminal.feed(&bytes);
}

fn upload(terminal: &mut VtTerminal, id: u32, side: usize, red: u8) {
    let mut pixels = vec![0; side * side * 3];
    for pixel in pixels.chunks_exact_mut(3) {
        pixel.copy_from_slice(&[red, 37, 91]);
    }
    let encoded = encode64(&pixels);
    let chunks: Vec<_> = encoded.as_bytes().chunks(4096).collect();
    for (index, chunk) in chunks.iter().enumerate() {
        let more = usize::from(index + 1 < chunks.len());
        let header = if index == 0 {
            format!("a=t,f=24,s={side},v={side},i={id},q=2,m={more}")
        } else {
            format!("q=2,m={more}")
        };
        command(terminal, &header, chunk);
    }
}

fn place(terminal: &mut VtTerminal, id: u32, placement: u32) {
    command(terminal, &format!("a=p,i={id},p={placement},c=1,r=1,C=1,q=2"), &[]);
}

fn hide(terminal: &mut VtTerminal, id: u32) {
    // Lowercase d=i removes placements while retaining the transmitted image.
    command(terminal, &format!("a=d,d=i,i={id},q=2"), &[]);
}

fn native_has(terminal: &VtTerminal, id: u32) -> bool {
    let mut graphics: ffi::GhosttyKittyGraphics = std::ptr::null_mut();
    assert_eq!(unsafe {
        ffi::ghostty_terminal_get(terminal.raw, ffi::GHOSTTY_TERMINAL_DATA_KITTY_GRAPHICS,
            (&mut graphics as *mut ffi::GhosttyKittyGraphics).cast())
    }, ffi::GHOSTTY_SUCCESS);
    !unsafe { ffi::ghostty_kitty_graphics_image(graphics, id) }.is_null()
}

fn terminal(raise_source_storage: bool) -> VtTerminal {
    let mut terminal = VtTerminal::new(80, 24, 0).unwrap();
    terminal.resize(80, 24, 8, 16).unwrap();
    if raise_source_storage {
        let source_storage_bytes: u64 = CAP as u64;
        assert_eq!(unsafe { ffi::ghostty_terminal_set(terminal.raw, 15,
            std::ptr::from_ref(&source_storage_bytes).cast()) }, ffi::GHOSTTY_SUCCESS);
    }
    terminal
}

fn ids(frame: &[VtImagePlacement]) -> HashSet<u32> {
    frame.iter().map(|p| p.image.id).collect()
}

fn snapshot(terminal: &mut VtTerminal, phase: &str, entries: usize, bytes: usize) -> Vec<VtImagePlacement> {
    let frame = terminal.image_placements().unwrap();
    let stats = terminal.probe_owned_cache_stats();
    assert_eq!(stats, (entries, bytes), "{phase}: cache statistics");
    assert_eq!(ids(&frame).len(), entries, "{phase}: unique frame assets");
    println!("phase={phase} unique_assets={entries} owned_rgba_bytes={bytes} placements={}", frame.len());
    frame
}

fn ownership(expect_unbounded: bool) {
    let mut terminal = terminal(true);
    println!("scenario=rgba_bytes source_storage_bytes={} source_storage_scope=disposable_terminal asset_format=RGB asset_side=1024", CAP);
    for id in 1..=16 {
        upload(&mut terminal, id, 1024, id as u8);
        place(&mut terminal, id, id);
    }
    let warm = snapshot(&mut terminal, "warm_16", 16, CAP);
    place(&mut terminal, 1, 1001);
    let duplicate = snapshot(&mut terminal, "duplicate_sharing", 16, CAP);
    let shared: Vec<_> = duplicate.iter().filter(|p| p.image.id == 1).collect();
    assert_eq!(shared.len(), 2);
    assert!(Arc::ptr_eq(&shared[0].image, &shared[1].image));
    upload(&mut terminal, 17, 1024, 17);
    place(&mut terminal, 17, 17);
    if expect_unbounded {
        let frame = snapshot(&mut terminal, "baseline_unbounded", 17, 68 * MIB);
        assert!(frame.iter().any(|p| p.image.id == 17));
        println!("result=EXPECTED_UNBOUNDED_BASELINE");
        return;
    }
    let capped = snapshot(&mut terminal, "omit_17_preserve_warm", 16, CAP);
    assert_eq!(ids(&capped), ids(&warm));
    for before in &warm {
        let after = capped.iter().find(|p| p.image.id == before.image.id).unwrap();
        assert!(Arc::ptr_eq(&before.image, &after.image), "visible warm image was replaced");
    }
    assert!(native_has(&terminal, 17));
    hide(&mut terminal, 1);
    let recovered = snapshot(&mut terminal, "same_snapshot_recovery", 16, CAP);
    assert!(ids(&recovered).contains(&17));
    assert!(!ids(&recovered).contains(&1));
    assert!(native_has(&terminal, 1), "offscreen source was deleted");

    let old = Arc::clone(&recovered.iter().find(|p| p.image.id == 2).unwrap().image);
    upload(&mut terminal, 2, 512, 222);
    place(&mut terminal, 2, 2);
    upload(&mut terminal, 18, 512, 223);
    place(&mut terminal, 18, 18);
    let replaced = snapshot(&mut terminal, "stale_generation_replacement_and_admission", 17, 62 * MIB);
    let current = &replaced.iter().find(|p| p.image.id == 2).unwrap().image;
    assert_ne!(current.generation, old.generation);
    assert_eq!((current.width, current.height), (512, 512));
    assert_eq!(current.rgba[0], 222);
    assert_eq!(old.rgba.len(), 4 * MIB);
    assert_eq!(old.rgba[0], 2, "old frame pixels changed after replacement");
    assert!(ids(&replaced).contains(&18));
    command(&mut terminal, "a=d,d=a,q=2", &[]);
    snapshot(&mut terminal, "empty_cleanup", 0, 0);
    assert!(native_has(&terminal, 2), "placement cleanup deleted source pixels");
    println!("scope=owned_cache prior_frame_arcs_may_retain_additional_pixels=true");
}

fn entry_admission() {
    let mut terminal = terminal(false);
    println!("scenario=entry_count source_storage_scope=production_default asset_format=RGB asset_side=1");
    for id in 1..=256 {
        upload(&mut terminal, id, 1, (id % 256) as u8);
        place(&mut terminal, id, id);
    }
    let warm = snapshot(&mut terminal, "entries_warm_256", 256, 1024);
    upload(&mut terminal, 257, 1, 99);
    place(&mut terminal, 257, 257);
    let capped = snapshot(&mut terminal, "entries_omit_257_preserve_warm", 256, 1024);
    assert_eq!(ids(&warm), ids(&capped));
    assert!(!ids(&capped).contains(&257));
    hide(&mut terminal, 1);
    let recovered = snapshot(&mut terminal, "entries_same_snapshot_recovery", 256, 1024);
    assert!(ids(&recovered).contains(&257));
    assert!(native_has(&terminal, 1));
    command(&mut terminal, "a=d,d=a,q=2", &[]);
    snapshot(&mut terminal, "entries_empty_cleanup", 0, 0);
}

fn main() {
    let expect_unbounded = std::env::args().nth(1).as_deref() == Some("unbounded");
    ownership(expect_unbounded);
    if !expect_unbounded {
        entry_admission();
        println!("result=PASS");
    }
}
'''


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("renderer_checkout", type=Path)
    parser.add_argument("lib_directory", type=Path)
    parser.add_argument("--baseline-image-source", type=Path)
    parser.add_argument("--expect-unbounded", action="store_true")
    args = parser.parse_args()
    checkout = args.renderer_checkout.resolve()
    library = args.lib_directory.resolve()
    module = checkout / "apps/desktop/src/ghostty_vt"
    images = (args.baseline_image_source or module / "images.rs").resolve()
    archive = library / "libghostty-vt.a"
    for required in (module / "mod.rs", images, archive):
        if not required.is_file():
            parser.error(f"required input is missing: {required.name}")
    toolchain_text = (checkout / "apps/desktop/rust-toolchain.toml").read_text()
    toolchain = re.search(r'channel\s*=\s*"([^"]+)"', toolchain_text).group(1)
    print(f"production_images_sha256={sha256(images)}", flush=True)
    print(f"native_archive_sha256={sha256(archive)}", flush=True)
    print(f"mode={'unbounded_baseline' if args.expect_unbounded else 'bounded_production'} rust_toolchain={toolchain}", flush=True)
    with tempfile.TemporaryDirectory(prefix="owned-image-probe-") as directory:
        build = Path(directory)
        copied = build / "src/ghostty_vt"
        shutil.copytree(module, copied)
        shutil.copyfile(images, copied / "images.rs")
        mod_file = copied / "mod.rs"
        mod_file.write_text(mod_file.read_text().replace("mod images;", "pub(crate) mod images;"))
        with (copied / "images.rs").open("a") as copied_images:
            copied_images.write("\nimpl VtImageState { pub(crate) fn probe_owned_cache_stats(&self) -> (usize, usize) { (self.images.len(), self.images.values().map(|image| image.rgba.len()).sum()) } }\n")
        with (copied / "terminal.rs").open("a") as copied_terminal:
            copied_terminal.write("\nimpl VtTerminal { pub(crate) fn probe_owned_cache_stats(&self) -> (usize, usize) { self.images.probe_owned_cache_stats() } }\n")
        (build / "src/main.rs").write_text(RUST_MAIN)
        (build / "Cargo.toml").write_text('[package]\nname = "owned-image-probe"\nversion = "0.0.0"\nedition = "2024"\n[dependencies]\nimage = { version = "=0.25.10", default-features = false, features = ["png"] }\n')
        (build / "build.rs").write_text('fn main() { println!("cargo:rustc-link-search=native={}", std::env::var("PROBE_NATIVE_LIB_DIRECTORY").unwrap()); println!("cargo:rustc-link-lib=static=ghostty-vt"); }\n')
        env = dict(os.environ)
        env["PROBE_NATIVE_LIB_DIRECTORY"] = str(library)
        env.pop("CARGO_TARGET_DIR", None)
        env.pop("RUSTC_WRAPPER", None)
        compile_result = subprocess.run(["rustup", "run", toolchain, "cargo", "build", "--offline", "--release", "--quiet"], cwd=build, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if compile_result.returncode:
            diagnostic = compile_result.stdout + compile_result.stderr
            for private in (str(build), str(checkout), str(library)):
                diagnostic = diagnostic.replace(private, "[probe input]")
            sys.stderr.write(diagnostic)
            return compile_result.returncode
        run_result = subprocess.run([str(build / "target/release/owned-image-probe"), "unbounded" if args.expect_unbounded else "bounded"], cwd=build, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        sys.stdout.write(run_result.stdout)
        diagnostic = run_result.stderr.replace(str(build), "[temporary probe]")
        sys.stderr.write(diagnostic)
        return run_result.returncode


if __name__ == "__main__":
    sys.exit(main())
