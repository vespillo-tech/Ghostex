"""Inject image-only errors while exercising the actual native TerminalModel.

Usage: python3 image-error-probe.py RENDERER_CHECKOUT LIB_DIRECTORY
 [--baseline-source-dir PATH] [--expect-freeze]
Requires matching Rust1.95 release libraries. Copies production modules to a
temporary directory; only adds fault injection and private-cache inspection.
Uses a disposable shell PTY; launches no Ghostex app and changes no settings.
"""
from pathlib import Path
import argparse,shutil,subprocess,tempfile,json,hashlib
p=argparse.ArgumentParser(description=__doc__);p.add_argument('renderer',type=Path);p.add_argument('library',type=Path);p.add_argument('--expect-freeze',action='store_true');p.add_argument('--baseline-source-dir',type=Path);a=p.parse_args()
renderer=a.renderer.resolve();library=a.library.resolve();deps=renderer/'apps/desktop/target/release/deps';out=Path(tempfile.mkdtemp(prefix='gx-image-error-probe-'))
src=renderer/'apps/desktop/src'
shutil.copytree(src/'ghostty_vt',out/'ghostty_vt');shutil.copytree(src/'terminal_model',out/'terminal_model');shutil.copy2(src/'terminal_model.rs',out/'terminal_model.rs')
if a.baseline_source_dir:
 for name in ['terminal_model.rs','ghostty_vt/images.rs']:
  shutil.copy2(a.baseline_source_dir/'apps/desktop/src'/name,out/name)
for name in ['terminal_model.rs','ghostty_vt/images.rs']:
 print('source='+name+' sha256='+hashlib.sha256((out/name).read_bytes()).hexdigest(),flush=True)
print('native_archive_sha256='+hashlib.sha256((library/'libghostty-vt.a').read_bytes()).hexdigest(),flush=True)
f=out/'ghostty_vt/images.rs';text=f.read_text()
needle='self.images.insert(id, Arc::clone(&image));';assert text.count(needle)==1
text=text.replace(needle,needle+' crate::COPIED_BYTES.fetch_add(image.rgba.len(),std::sync::atomic::Ordering::SeqCst);')
late_index=21 if 'GHOSTTY_KITTY_GRAPHICS_PLACEMENT_DATA_X_OFFSET' in text else 17
print('late_fault_call='+str(late_index),flush=True)
text+='''
// Validation only: fail one image-path FFI-result check, never text calls.
fn check(result: ffi::GhosttyResult) -> Result<(), VtError> {
 let n=crate::IMAGE_CALL.fetch_add(1,std::sync::atomic::Ordering::SeqCst)+1;
 if crate::FAIL_AT.load(std::sync::atomic::Ordering::SeqCst)==n {
  Err(VtError{code:ffi::GHOSTTY_INVALID_VALUE})
 } else {super::check(result)}
}
impl VtImageState {
 pub(crate) fn probe_bytes(&self)->usize{self.images.values().map(|v|v.rgba.len()).sum()}
 pub(crate) fn probe_clear(&mut self){self.images.clear()}
}
''';f.write_text(text)
f=out/'ghostty_vt/terminal.rs';f.write_text(f.read_text()+'''\nimpl VtTerminal {
 pub(crate) fn probe_bytes(&self)->usize{self.images.probe_bytes()}
 pub(crate) fn probe_clear(&mut self){self.images.probe_clear()}
}\n''')
f=out/'terminal_model.rs';f.write_text(f.read_text()+'''\nimpl TerminalModel {
 pub(crate) fn probe_bytes(&self)->usize{self.terminal.lock().unwrap().as_ref().unwrap().probe_bytes()}
 pub(crate) fn probe_clear(&mut self){self.terminal.lock().unwrap().as_mut().unwrap().probe_clear()}
}\n''')
source=r'''#![allow(dead_code,unused_imports)]
#[path=VT] mod ghostty_vt;
#[path=ENV] mod terminal_environment;
#[path=MODEL] mod terminal_model;
use terminal_model::*;
use std::{sync::{Arc,atomic::{AtomicUsize,Ordering}},time::{Duration,Instant}};
static FAIL_AT:AtomicUsize=AtomicUsize::new(0);
static IMAGE_CALL:AtomicUsize=AtomicUsize::new(0);
static COPIED_BYTES:AtomicUsize=AtomicUsize::new(0);
fn wait_title(model:&mut TerminalModel,title:&str){
 let end=Instant::now()+Duration::from_secs(4);
 while model.title().as_deref()!=Some(title){assert!(Instant::now()<end);std::thread::sleep(Duration::from_millis(10));}
}
fn main()->anyhow::Result<()> {
 let old=std::env::args().any(|v|v=="freeze");
 let producer=r#"printf '\033_Ga=T,f=32,s=1,v=1,i=101,c=1,r=1,q=2;HuZk/w==\033\\'; printf '\033[1;4H\033_Ga=T,f=32,s=1,v=1,i=102,c=1,r=1,q=2;HuZk/w==\033\\'; printf '\r\nSTART\033]2;READY\007'; while IFS= read -r line; do printf '\r\n%s\033]2;%s\007' "$line" "$line"; done"#;
 let mut model=TerminalModel::spawn(TerminalSpawnConfig{program:"/bin/sh".into(),args:vec!["-c".into(),producer.into()],env:vec![],cwd:None,cols:80,rows:24,cell_width_px:8,cell_height_px:16,max_scrollback:1_000_000},Arc::new(|_|{}))?;
 wait_title(&mut model,"READY");assert_eq!(model.snapshot()?.images.len(),2);println!("PASS initial actual native model text and two images");
 for (name,at) in [("EARLY",1),("LATE",__LATE_INDEX__)] {
  model.probe_clear();COPIED_BYTES.store(0,Ordering::SeqCst);IMAGE_CALL.store(0,Ordering::SeqCst);FAIL_AT.store(at,Ordering::SeqCst);
  model.write_input(format!("{name}\n").as_bytes())?;wait_title(&mut model,name);
  let frame=model.snapshot();
  if name=="LATE"{assert!(COPIED_BYTES.load(Ordering::SeqCst)>0);println!("PASS late fault occurred after owned pixels were copied");}
  if old {assert!(frame.is_err());println!("PASS negative control: {name} image error aborts whole text frame");}
  else {
   let frame=frame?;assert!(frame.images.is_empty());assert!(frame.rows.iter().any(|r|r.text().contains(name)));assert_eq!(model.probe_bytes(),if name=="LATE"{4}else{0});
   println!("PASS {name} image-only failure: latest text, no frame images, bounded valid cache retained");
  }
  if name=="LATE" {
   COPIED_BYTES.store(0,Ordering::SeqCst);IMAGE_CALL.store(0,Ordering::SeqCst);
   model.write_input(b"LATE_STREAK\n")?;wait_title(&mut model,"LATE_STREAK");
   let repeated=model.snapshot();
   if old {assert!(repeated.is_err());} else {let f=repeated?;assert!(f.images.is_empty());assert!(f.rows.iter().any(|r|r.text().contains("LATE_STREAK")));}
   assert_eq!(COPIED_BYTES.load(Ordering::SeqCst),0);
   println!("PASS repeated late failure retains warm pixels without recopy; text {}",if old {"aborts"}else{"advances"});
  }
  FAIL_AT.store(0,Ordering::SeqCst);let frame=model.snapshot()?;assert_eq!(frame.images.len(),2);assert!(frame.rows.iter().any(|r|r.text().contains(name)));
  println!("PASS {name} next successful snapshot recovers unchanged source images");
 }
 model.kill()?;Ok(())
}
'''
source=source.replace('__LATE_INDEX__',str(late_index))
for key,path in [('VT',out/'ghostty_vt/mod.rs'),('ENV',src/'terminal_environment.rs'),('MODEL',out/'terminal_model.rs')]:source=source.replace('path='+key,'path='+json.dumps(str(path)))
rs=out/'probe.rs';rs.write_text(source);binary=out/'probe'
portable=sorted(deps.glob('libportable_pty-*.rlib'));assert len(portable)==1
# Some caches contain both debug/release anyhow identities. Select only an
# identity accepted by rustc for the actual portable_pty dependency graph.
for anyhow in sorted(deps.glob('libanyhow-*.rlib')):
 cmd=['rustc','+1.95.0','--edition=2024','-O',str(rs),'-o',str(binary),'-L','dependency='+str(deps),'-L','native='+str(library),'-lstatic=ghostty-vt','-lc++','--extern','portable_pty='+str(portable[0]),'--extern','anyhow='+str(anyhow)]
 for name in ['image','libc']:cmd+=['--extern',name+'='+str(sorted(deps.glob('lib'+name+'-*.rlib'))[0])]
 result=subprocess.run(cmd,capture_output=True,text=True)
 if result.returncode==0:break
 if 'E0460' not in result.stderr:raise RuntimeError(result.stderr)
else:raise RuntimeError('No matching anyhow dependency identity')
result=subprocess.run([str(binary),*(['freeze'] if a.expect_freeze else [])],capture_output=True,text=True,timeout=20)
print(result.stdout,end='');print(result.stderr,end='')
result.check_returncode()
if not a.expect_freeze:assert result.stderr.count('Kitty image snapshot failed')==2
