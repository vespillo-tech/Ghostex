#!/usr/bin/env python3
"""Compare exact before/after ordered-grid parsers and time ordinary output.
Usage: viewer-grid-probe.py BASELINE_SOURCE CANDIDATE_SOURCE
Uses rustc1.95.0 and disposable source; no app or repository test changes.
"""
from pathlib import Path
import argparse, hashlib, subprocess, tempfile
p=argparse.ArgumentParser();p.add_argument('baseline');p.add_argument('candidate');a=p.parse_args()
before=Path(a.baseline).resolve();after=Path(a.candidate).resolve()
source=r'''
#![allow(dead_code)]
#[path="__BEFORE__"] mod before;
#[path="__AFTER__"] mod after;
use std::{hint::black_box, time::Instant};
#[derive(Debug, PartialEq, Eq)] enum Event {Bytes(Vec<u8>), Grid(Option<(u16,u16,u32,u32)>)}
fn bytes(out:&mut Vec<Event>, b:&[u8]) {
 if b.is_empty(){return;}
 if let Some(Event::Bytes(last))=out.last_mut(){last.extend_from_slice(b)}
 else {out.push(Event::Bytes(b.to_vec()))}
}
macro_rules! runner {($name:ident,$module:ident)=>{
 fn $name(input:&[u8], cuts:&[usize])->Vec<Event>{
  let mut parser=$module::ViewerGridParser::new("0123456789abcdef0123456789abcdef");
  let mut out=Vec::new();let mut start=0;
  for &end in cuts.iter().chain(std::iter::once(&input.len())) {
   parser.feed(&input[start..end],|c|{match c {
    $module::ViewerGridChunk::Bytes(b)=>bytes(&mut out,b),
    $module::ViewerGridChunk::Grid(g)=>out.push(Event::Grid(g.map(|v|(v.cols,v.rows,v.cell_width,v.cell_height))))
   };Ok::<_,()>(())}).unwrap();start=end;
  }
  parser.finish(|b|{bytes(&mut out,b);Ok::<_,()>(())}).unwrap();out
 }
};}
runner!(old,before);runner!(new,after);
macro_rules! bench {($name:ident,$module:ident)=>{
 fn $name(data:&[u8],label:&str){
  let mut parser=$module::ViewerGridParser::new("0123456789abcdef0123456789abcdef");
  parser.feed(data,|c|{match c {
    $module::ViewerGridChunk::Bytes(b)=>{assert_eq!(b.as_ptr(),data.as_ptr());assert_eq!(b.len(),data.len())},
    _=>panic!("unexpected record")};Ok::<_,()>(())}).unwrap();
  let mut ns=Vec::new();for _ in 0..3 {
   let start=Instant::now();for _ in 0..128 {
    parser.feed(black_box(data),|c|{if let $module::ViewerGridChunk::Bytes(b)=c {black_box(b);}Ok::<_,()>(())}).unwrap();
   } ns.push(start.elapsed().as_nanos());
  } println!("benchmark parser={} workload={} bytes_per_run={} runs_ns={:?}",stringify!($module),label,data.len()*128,ns);
 }
};}
bench!(bench_old,before);bench!(bench_new,after);
fn main(){
 let nonce="0123456789abcdef0123456789abcdef";
 let prefix=format!("\x1b_ZMX_GRID;{nonce};");
 let record=format!("{prefix}0018005002800180\x1b\\").into_bytes();
 let reset=format!("{prefix}0000000000000000\x1b\\").into_bytes();
 let mut cases=vec![];
 let mut add=|name:&str,b:Vec<u8>,e:Vec<Event>|cases.push((name.to_string(),b,e));
 add("plain",b"ordinary terminal text".to_vec(),vec![Event::Bytes(b"ordinary terminal text".to_vec())]);
 add("ANSI",b"\x1b[31mred\x1b[0m\x1b]title\x07\x9b31m".to_vec(),vec![Event::Bytes(b"\x1b[31mred\x1b[0m\x1b]title\x07\x9b31m".to_vec())]);
 add("grid",record.clone(),vec![Event::Grid(Some((80,24,8,16)))]);
 add("reset",reset.clone(),vec![Event::Grid(None)]);
 for (name,left,right) in [("UTF8",&[0xf0,0x9f][..],&[0x98,0x80][..]),("CSI",&b"\x1b["[..],&b"31mred"[..]),("Kitty",&b"\x1b_Ga=T,f=32;AA"[..],&b"AAAA==\x1b\\"[..])] {
  let b=[left,record.as_slice(),right].concat();
  add(name,b,vec![Event::Bytes(left.to_vec()),Event::Grid(Some((80,24,8,16))),Event::Bytes(right.to_vec())]);
 }
 let invalid=format!("{prefix}00180050ZZZZ0180\x1b\\").into_bytes();
 let zerocol=format!("{prefix}0018000002800180\x1b\\").into_bytes();
 let terminator=format!("{prefix}0018005002800180XY").into_bytes();
 let unknown=b"\x1b_ZMX_GRID;fedcba9876543210fedcba9876543210;0018005002800180\x1b\\".to_vec();
 for (name,b) in [("badhex",invalid),("zero-cols",zerocol),("bad-terminator",terminator),("wrong-nonce",unknown)] {add(name,b.clone(),vec![Event::Bytes(b)]);}
 add("adjacent",[record.as_slice(),reset.as_slice()].concat(),vec![Event::Grid(Some((80,24,8,16))),Event::Grid(None)]);
 for n in 1..record.len(){let b=record[..n].to_vec();add(&format!("incomplete-{n}"),b.clone(),vec![Event::Bytes(b)]);}
 let mut checks=0;
 for (name,input,expected) in cases {
  assert_eq!(new(&input,&[]),expected,"{name}: independent expected output");
  for i in 0..=input.len(){for j in i..=input.len(){
   let cuts=[i,j];let actual=new(&input,&cuts);
   assert_eq!(actual,expected,"{name} expected cuts{i}/{j}");
   assert_eq!(actual,old(&input,&cuts),"{name} equivalence cuts{i}/{j}");checks+=1;
  }}
  let cuts:Vec<_>=(0..input.len()).collect();assert_eq!(new(&input,&cuts),expected,"{name} bytewise");checks+=1;
 }
 // Propagate callback failure and preserve pending partial-prefix bytes.
 let mut p=after::ViewerGridParser::new(nonce);
 assert_eq!(p.feed(b"text",|_|Err::<(),_>("consumer")),Err("consumer"));
 assert!(p.feed(prefix.as_bytes(),|_|Ok::<_,()>(())).is_ok());
 let mut recovered=Vec::new();p.finish(|b|{recovered.extend_from_slice(b);Ok::<_,()>(())}).unwrap();assert_eq!(recovered,prefix.as_bytes());
 println!("PASS boundary_equivalence_checks={checks} independent_expected_output=true callback_errors=true");
 let ascii=vec![b'x';1024*1024];
 let pattern=b"\x1b[31mexample output\x1b[0m\n";let ansi=pattern.repeat(1024*1024/pattern.len());
 bench_old(&ascii,"ASCII");bench_new(&ascii,"ASCII");bench_old(&ansi,"ANSI");bench_new(&ansi,"ANSI");
}
'''.replace('__BEFORE__',str(before)).replace('__AFTER__',str(after))
print('baseline_sha256='+hashlib.sha256(before.read_bytes()).hexdigest(),flush=True)
print('candidate_sha256='+hashlib.sha256(after.read_bytes()).hexdigest(),flush=True)
with tempfile.TemporaryDirectory(prefix='ghostex-grid-review-') as td:
 rs=Path(td)/'probe.rs';rs.write_text(source);binary=Path(td)/'probe'
 subprocess.run(['rustc','+1.95.0','--edition=2024','-O',str(rs),'-o',str(binary)],check=True)
 subprocess.run([str(binary)],check=True)
