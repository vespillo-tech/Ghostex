"""Verify the inherited lib-vt storage budget using actual production modules.

Usage: python3 storage-limit-probe.py RENDERER_CHECKOUT LIBGHOSTTY_VT_DIRECTORY
Requires matching Rust1.95 release dependencies. Launches no app and writes
only probe artifacts beside this script. The raised-budget contrast changes
only a disposable in-memory terminal, never application settings.
"""
import argparse
import base64
import json
import subprocess
import zlib
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('renderer', type=Path)
p.add_argument('library', type=Path)
a = p.parse_args()
out = Path(__file__).parent
renderer = a.renderer.resolve()
deps = renderer / 'apps/desktop/target/release/deps'
library = a.library.resolve()
assert (library / 'libghostty-vt.a').is_file()


def stream(side):
    pixels = zlib.compress(bytes([220, 45, 55, 255]) * side * side, 1)
    payload = base64.b64encode(pixels)
    chunks = [payload[i:i + 4096] for i in range(0, len(payload), 4096)]
    result = b'\x1b[4;1H'
    for n, chunk in enumerate(chunks):
        more = int(n + 1 < len(chunks))
        header = (f'a=T,f=32,s={side},v={side},o=z,i=101,c=9,r=4,m={more}'
                  if n == 0 else f'm={more}')
        result += b'\x1b_G' + header.encode() + b';' + chunk + b'\x1b\\'
    return result


small = out / 'storage-small-stream.bin'
large = out / 'storage-large-stream.bin'
small.write_bytes(stream(16))
large.write_bytes(stream(2048))
source = '''#![allow(dead_code, unused_imports)]
#[path = MODULE_PATH] mod ghostty_vt;
use ghostty_vt::{VtTerminal, ffi};
fn terminal() -> VtTerminal {
 let mut vt=VtTerminal::new(120,50,1000000).unwrap();
 vt.resize(120,50,8,16).unwrap();vt
}
fn main() {
 let args:Vec<_>=std::env::args().collect();
 let small=std::fs::read(&args[1]).unwrap();let large=std::fs::read(&args[2]).unwrap();
 let mut vt=terminal();let mut bytes=0u64;
 // Existing C API terminal.h: storage data key26; storage option15.
 assert_eq!(unsafe{ffi::ghostty_terminal_get(vt.raw,26,(&mut bytes as *mut u64).cast())},0);
 assert_eq!(bytes,10_000_000);println!("PASS inherited lib-vt storage: {} bytes/screen",bytes);
 vt.feed(&small);assert_eq!(vt.image_placements().unwrap().len(),1);
 println!("PASS small raw image accepted under unchanged default");
 let mut vt=terminal();vt.feed(&large);assert!(vt.image_placements().unwrap().is_empty());
 println!("PASS 16MiB RGBA image refused under unchanged10MB source budget");
 let raised=64*1024*1024u64;
 assert_eq!(unsafe{ffi::ghostty_terminal_set(vt.raw,15,(&raised as *const u64).cast())},0);
 vt.feed(&large);let placements=vt.image_placements().unwrap();assert_eq!(placements.len(),1);
 assert_eq!(placements[0].image.rgba.len(),16*1024*1024);
 println!("PASS identical transfer accepted after disposable in-memory storage increase");
}
'''.replace('MODULE_PATH', json.dumps(str(renderer / 'apps/desktop/src/ghostty_vt/mod.rs')))
rs = out / 'storage-limit-probe.rs'
rs.write_text(source)
command = ['rustc', '+1.95.0', '--edition=2024', '-O', str(rs),
           '-L', 'dependency=' + str(deps), '-L', 'native=' + str(library),
           '-lstatic=ghostty-vt', '-lc++', '-o', str(out / 'storage-limit-probe')]
for name in ['image', 'libc']:
    command += ['--extern', name + '=' + str(sorted(deps.glob('lib' + name + '-*.rlib'))[0])]
subprocess.run(command, check=True)
raise SystemExit(subprocess.run([str(out / 'storage-limit-probe'), str(small), str(large)]).returncode)
