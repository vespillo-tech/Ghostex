#!/usr/bin/env python3
"""Public fixture for upload admission/recovery and placeholder cursor shaping.

Run only in a disposable terminal. The default uses256 tiny images, then
`add` introduces one new generation after the cache is warm. `large` as a
command-line argument demonstrates the inherited10MB source-storage refusal.
The fixture ends after ten minutes. Commands: add, recover, cursor, redraw, quit.
"""
import base64
import select
import sys
import time
import zlib

out = sys.stdout.buffer
colors = [(220, 45, 55), (40, 210, 90), (40, 90, 220),
          (235, 175, 35), (175, 70, 210)]


def emit(value):
    out.write(value.encode() if isinstance(value, str) else value)
    out.flush()


def at(row, col, text=""):
    emit(f"\x1b[{row};{col}H{text}")


def image(control, pixels=b""):
    payload = base64.b64encode(pixels)
    chunks = [payload[i:i + 4096] for i in range(0, len(payload), 4096)] or [b""]
    for n, chunk in enumerate(chunks):
        more = int(n + 1 < len(chunks))
        header = f"{control},m={more}" if n == 0 else f"m={more},q=2"
        emit(b"\x1b_G" + header.encode() + b";" + chunk + b"\x1b\\")


def large():
    image("a=d,d=A,q=2")
    emit("\x1b[2J\x1b[H\x1b[?25h\x1b[2 q")
    at(1, 1, "SOURCE LIMIT CONTROL: 16MiB/images exceed inherited10MB storage")
    at(2, 1, "Valid transfers are refused before GPUI uploads are constructed.")
    for n, color in enumerate(colors):
        col = 1 + n * 11
        at(3, col, str(n + 1))
        at(4, col)
        pixels = zlib.compress(bytes((*color, 255)) * (2048 * 2048), 1)
        image(f"a=T,f=32,s=2048,v=2048,o=z,i={101+n},c=9,r=4,q=2", pixels)
    at(10, 1, "Commands: cursor, redraw, quit")
    at(12, 1, "review> ")


def count_image(n):
    row, col = 3 + (n // 16) * 2, 1 + (n % 16) * 4
    color = (230, 40, 180) if n == 256 else colors[n % len(colors)]
    at(row, col)
    image(f"a=T,f=32,s=1,v=1,i={101+n},c=3,r=1,q=2", bytes((*color, 255)))


def draw():
    if len(sys.argv) > 1 and sys.argv[1] == 'large':
        large()
        return
    image("a=d,d=A,q=2")
    emit("\x1b[2J\x1b[H\x1b[?25h\x1b[2 q")
    at(1, 1, "REVIEW LAB:256 tiny visible image generations")
    for n in range(256):
        count_image(n)
    at(35, 7, "LAST SLOT: add must omit; recover admits magenta")
    at(38, 1, "Commands: add, recover, cursor, redraw, quit")
    at(40, 1, "review> ")


def cursor():
    image("a=d,d=A,q=2")
    emit("\x1b[2J\x1b[H")
    at(1, 1, "CURSOR CHECK: block over a green Kitty placeholder; no glyph box")
    image("a=T,f=32,s=1,v=1,i=52,c=16,r=6,U=1,q=2,z=-1", bytes([30, 230, 100, 255]))
    marks = ["\u0305", "\u030d", "\u030e", "\u0310", "\u0312", "\u033d"]
    for row, mark in enumerate(marks):
        at(4 + row, 24, "\x1b[38;2;0;0;52m" + "\U0010eeee" + mark + marks[0] + "\U0010eeee" * 15 + "\x1b[0m")
    at(12, 1, "The focused block remains. Commands: recover, cursor, redraw, quit")
    at(6, 24)
    emit("\x1b[2 q\x1b[?25h")


draw()
end = time.monotonic() + 600
while time.monotonic() < end:
    ready, _, _ = select.select([sys.stdin], [], [], 0.25)
    if not ready:
        continue
    line = sys.stdin.readline()
    if not line:
        break
    command = line.strip()
    if command == "quit":
        break
    if command == "add":
        count_image(256)
        at(37, 1, "257th generation sent; source retained, upload omitted.")
        at(40, 1, "review> ")
    elif command == "recover":
        image("a=d,d=I,i=101,q=2")
        image("a=d,d=I,i=102,q=2")
        at(37, 1, "Deleted first2; retained257th image can now be uploaded.")
        at(40, 1, "review> ")
    elif command == "cursor":
        cursor()
    elif command == "redraw":
        draw()
emit("\x1b[?25h\r\nReview fixture finished.\r\n")
