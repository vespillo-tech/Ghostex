"""Exercise the production cursor/cache functions with controlled host services.

No app is launched. RenderImage uses the real image crate pixel buffers; the
window only records text shaping and atlas cleanup requests. This validates
admission/allocation and glyph selection, not GPU memory or native screenshots.
"""
import argparse
import re
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('renderer', type=Path)
p.add_argument('case', choices=['cursor', 'cache', 'all'])
a = p.parse_args()
out = Path(__file__).parent
desktop = a.renderer / 'apps/desktop'

def function(source, name):
    match = re.search(r'^(?:pub\(super\) )?fn '+name+r'\(', source, re.M)
    assert match, name
    brace = source.index('{', match.start())
    depth = 0
    for i in range(brace, len(source)):
        depth += (source[i] == '{') - (source[i] == '}')
        if depth == 0:
            return source[match.start():i+1].replace('pub(super) fn ', 'fn ', 1)
    raise AssertionError(name)

cache = (desktop/'src/terminal_element/kitty_images.rs').read_text()
cursor = (desktop/'src/terminal_element.rs').read_text()
constants = '\n'.join(re.findall(r'^const MAX_IMAGE_CACHE_\w+:[^;]+;', cache, re.M))
if not constants:
    constants = 'const MAX_IMAGE_CACHE_BYTES: usize = 64 * 1024 * 1024;\nconst MAX_IMAGE_CACHE_ENTRIES: usize = 256;'
source = r'''
use std::{collections::{HashMap,HashSet},sync::{Arc,atomic::{AtomicUsize,Ordering}}};
use image::Frame;
static ALLOCATIONS:AtomicUsize=AtomicUsize::new(0);
pub struct RenderImage{data:Vec<Frame>}
impl RenderImage{
 fn new(data:Vec<Frame>)->Self{ALLOCATIONS.fetch_add(1,Ordering::SeqCst);Self{data}}
 fn as_bytes(&self,n:usize)->Option<&[u8]>{self.data.get(n).map(|f|f.buffer().as_raw().as_slice())}
}
#[derive(Default)]pub struct App{dropped:usize}
impl App{fn drop_image(&mut self,_:Arc<RenderImage>,_:Option<&mut Window>){self.dropped+=1;}}
#[derive(Default)]pub struct TextSystem{calls:usize}
impl TextSystem{fn shape_line(&mut self,text:SharedString,_:f32,_:&[TextRun],_:Option<f32>)->String{self.calls+=1;text.0}}
#[derive(Default)]pub struct Window{system:TextSystem}
impl Window{fn text_system(&mut self)->&mut TextSystem{&mut self.system}}
pub struct SharedString(String);
impl From<String> for SharedString{fn from(v:String)->Self{Self(v)}}
#[derive(Clone,Copy,Debug,PartialEq)]pub enum TerminalCursorShape{Block,Beam,Underline}
#[derive(Clone,Copy)]pub enum VtCellWide{Narrow,Wide}
pub struct Cell{base:char,combining:Option<String>,width:VtCellWide,bold:bool,italic:bool}
pub struct SnapshotRow{cells:Vec<Cell>}
#[derive(Clone,Copy)]pub struct Hsla{a:f32}
#[derive(Clone,Copy)]pub struct TerminalConfiguredColor;
impl TerminalConfiguredColor{fn resolve(self,_:&TerminalSnapshot)->[u8;3]{[1,2,3]}}
pub struct TerminalFontConfig{size:f32}
#[derive(Clone,Copy)]pub struct CellMetrics{cell_width:f32}
pub struct TextRun{len:usize,font:usize,color:Hsla,background_color:Option<Hsla>,underline:Option<()>,strikethrough:Option<()>}
pub struct CursorLayout{col:u16,row:u16,width_cells:u8,shape:TerminalCursorShape,color:Hsla,hollow:bool,overlay:Option<String>}
fn cell_is_blank(c:&Cell)->bool{c.base==' '&&c.combining.is_none()}
fn rgb_to_hsla(_:[u8;3])->Hsla{Hsla{a:1.0}}
fn base_font(_: &TerminalFontConfig,_:bool,_:bool)->usize{0}
pub mod ghostty_vt{
 use super::*;
 pub struct VtImage{pub id:u32,pub generation:u64,pub width:u32,pub height:u32,pub rgba:Vec<u8>}
 #[derive(Clone)]pub struct VtImagePlacement{pub image:Arc<VtImage>}
}
pub struct TerminalSnapshot{images:Vec<ghostty_vt::VtImagePlacement>,cursor_visible:bool,cursor:Option<(u16,u16)>,rows:Vec<SnapshotRow>,cursor_color:Option<[u8;3]>,foreground:[u8;3],background:[u8;3]}
fn snapshot(images:Vec<ghostty_vt::VtImagePlacement>)->TerminalSnapshot{TerminalSnapshot{images,cursor_visible:true,cursor:Some((0,0)),rows:vec![],cursor_color:None,foreground:[255;3],background:[0;3]}}
fn placement(id:u32,w:u32,h:u32)->ghostty_vt::VtImagePlacement{ghostty_vt::VtImagePlacement{image:Arc::new(ghostty_vt::VtImage{id,generation:id as u64,width:w,height:h,rgba:vec![255;(w as usize)*(h as usize)*4]})}}
fn bytes(cache:&HashMap<u64,Arc<RenderImage>>)->usize{cache.values().map(|i|i.as_bytes(0).unwrap().len()).sum()}
fn cursor_cases(){
 let mut frame=snapshot(vec![]);frame.rows=vec![SnapshotRow{cells:vec![Cell{base:'\u{10eeee}',combining:Some("\u{301}\u{302}".into()),width:VtCellWide::Narrow,bold:false,italic:false}]}];
 let config=TerminalFontConfig{size:12.0};let metrics=CellMetrics{cell_width:8.0};let mut window=Window::default();
 let c=layout_cursor(TerminalCursorShape::Block,1.0,None,true,&frame,&config,metrics,&mut window).unwrap();
 assert!(c.overlay.is_none(),"native block cursor must not shape Kitty placeholder/marks");assert!(!c.hollow);assert_eq!(c.shape,TerminalCursorShape::Block);assert_eq!(window.system.calls,0);println!("PASS cursor placeholder has no glyph; block retained");
 for shape in [TerminalCursorShape::Beam,TerminalCursorShape::Underline]{assert!(layout_cursor(shape,1.0,None,true,&frame,&config,metrics,&mut window).unwrap().overlay.is_none());}println!("PASS beam/underline unchanged");
 assert!(layout_cursor(TerminalCursorShape::Beam,1.0,None,false,&frame,&config,metrics,&mut window).unwrap().hollow);println!("PASS unfocused hollow cursor retained");
 frame.rows[0].cells[0].base='a';frame.rows[0].cells[0].combining=Some("\u{301}".into());
 assert_eq!(layout_cursor(TerminalCursorShape::Block,1.0,None,true,&frame,&config,metrics,&mut window).unwrap().overlay.as_deref(),Some("a\u{301}"));println!("PASS normal combined glyph retained");
 frame.rows[0].cells[0].base=' ';frame.rows[0].cells[0].combining=None;assert!(layout_cursor(TerminalCursorShape::Block,1.0,None,true,&frame,&config,metrics,&mut window).unwrap().overlay.is_none());println!("PASS blank cell unchanged");
 frame.rows[0].cells[0].base='界';frame.rows[0].cells[0].width=VtCellWide::Wide;assert_eq!(layout_cursor(TerminalCursorShape::Block,1.0,None,true,&frame,&config,metrics,&mut window).unwrap().width_cells,2);println!("PASS wide cursor width retained");
 frame.cursor_visible=false;assert!(layout_cursor(TerminalCursorShape::Block,1.0,None,true,&frame,&config,metrics,&mut window).is_none());frame.cursor_visible=true;frame.cursor=None;assert!(layout_cursor(TerminalCursorShape::Block,1.0,None,true,&frame,&config,metrics,&mut window).is_none());println!("PASS hidden/absent cursor unchanged");
}
fn cache_cases(){
 let mut cache=HashMap::new();let mut cx=App::default();let mut window=Window::default();
 let frame=snapshot((1..=5).map(|id|placement(id,2048,2048)).collect());let v=layout_images(&mut cache,&frame,&mut window,&mut cx);
 assert!(bytes(&cache)<=MAX_IMAGE_CACHE_BYTES,"aggregate upload bytes exceed budget: {}",bytes(&cache));assert_eq!(v.len(),3);println!("PASS aggregate bytes bounded before large uploads");drop(v);drop(frame);cache.clear();
 let mut frame=snapshot((1..=4).map(|id|placement(id,1022,4094)).collect());frame.images.push(placement(5,1,1));let before=ALLOCATIONS.load(Ordering::SeqCst);let v=layout_images(&mut cache,&frame,&mut window,&mut cx);
 assert_eq!(bytes(&cache),MAX_IMAGE_CACHE_BYTES);assert_eq!(v.len(),4);assert_eq!(ALLOCATIONS.load(Ordering::SeqCst)-before,4);println!("PASS exact padded-byte limit accepted; next allocation refused");
 let original=Arc::clone(&v[0].1);let alloc=ALLOCATIONS.load(Ordering::SeqCst);frame.images.rotate_right(1);let v=layout_images(&mut cache,&frame,&mut window,&mut cx);assert_eq!(v.len(),4);assert_eq!(ALLOCATIONS.load(Ordering::SeqCst),alloc);assert!(Arc::ptr_eq(&original,cache.get(&1).unwrap()));println!("PASS visible cached images retained even when new image is first");drop(original);drop(v);
 let frame=snapshot(vec![frame.images[0].clone()]);let dropped=cx.dropped;let v=layout_images(&mut cache,&frame,&mut window,&mut cx);assert_eq!(v.len(),1);assert_eq!(cache.len(),1);assert_eq!(cx.dropped-dropped,4);println!("PASS offscreen pruning frees budget and allows omitted image");
 assert!(v[0].1.as_bytes(0).unwrap().chunks_exact(4).all(|p|p==[255;4]));drop(v);drop(frame);cache.clear();
 let mut frame=snapshot((1..=257).map(|id|placement(id,1,1)).collect());frame.images.push(frame.images[0].clone());let alloc=ALLOCATIONS.load(Ordering::SeqCst);let v=layout_images(&mut cache,&frame,&mut window,&mut cx);assert_eq!(cache.len(),MAX_IMAGE_CACHE_ENTRIES);assert_eq!(v.len(),257);assert_eq!(ALLOCATIONS.load(Ordering::SeqCst)-alloc,256);assert!(Arc::ptr_eq(&v[0].1,&v.last().unwrap().1));println!("PASS count limit, duplicates and shared generation allocation");drop(v);cache.clear();
 let mut p=placement(300,1,1);Arc::get_mut(&mut p.image).unwrap().rgba=vec![10,20,30,255];let frame=snapshot(vec![p]);let v=layout_images(&mut cache,&frame,&mut window,&mut cx);let expected:[u8;4]=[30,20,10,255];assert_eq!(v[0].1.as_bytes(0).unwrap().len(),36);assert!(v[0].1.as_bytes(0).unwrap().chunks_exact(4).all(|p|p==expected));println!("PASS tiny replicated border and BGRA conversion");drop(v);
 let old=Arc::clone(cache.get(&300).unwrap());let mut p=placement(301,1,1);Arc::get_mut(&mut p.image).unwrap().id=300;let frame=snapshot(vec![p]);let dropped=cx.dropped;let v=layout_images(&mut cache,&frame,&mut window,&mut cx);assert_eq!(cache.len(),1);assert!(!Arc::ptr_eq(&old,&v[0].1));assert_eq!(cx.dropped-dropped,1);println!("PASS same-ID fresh generation replaces cached pixels");drop(v);
 let frame=snapshot(vec![]);let dropped=cx.dropped;assert!(layout_images(&mut cache,&frame,&mut window,&mut cx).is_empty());assert!(cache.is_empty());assert_eq!(cx.dropped-dropped,1);println!("PASS empty-frame atlas cleanup");
}
fn main(){let arg=std::env::args().nth(1).unwrap();if arg=="cursor"||arg=="all"{cursor_cases()}if arg=="cache"||arg=="all"{cache_cases()}}
'''
source += '\n'+constants+'\n'+function(cache,'layout_images')+'\n'+function(cursor,'layout_cursor')+'\n'
rs = out/'production-probe.rs'
rs.write_text(source)
deps = desktop/'target/release/deps'
image = sorted(deps.glob('libimage-*.rlib'))[0]
binary = out/'production-probe'
subprocess.run(['rustc','+1.95.0','--edition=2024','-O','-A','dead_code',str(rs),'-L','dependency='+str(deps),'--extern','image='+str(image),'-o',str(binary)],check=True)
raise SystemExit(subprocess.run([str(binary),a.case]).returncode)
