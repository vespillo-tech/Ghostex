# Draft: Render retained static Kitty images in the GPUI terminal

## Why

Ghostty already retains Kitty pixels and placements, but Ghostex's GPUI terminal did not paint them. Terminal image viewers and artwork could get a successful protocol reply yet display placeholders or no image. This connects retained state to GPUI and coordinates local zmx viewer resizing so image anchors remain correct.

The [companion zmx contribution](https://github.com/maddada/zmx/pull/3) restores images after attachment and refresh. Both changes must ship together with an exact reviewed dependency pin.

## Implementation and review map

- `ghostty_vt/images.rs`: copy pixels and placements under the exclusive VT lock; frames own generations and reuse unchanged pixels. Register the PNG decoder through the existing Rust image dependency and core allocator.
- Ghostty patches 0009/0010: expose the existing Unicode-placeholder iterator and precise source rectangles, retaining the native integer helper's behavior; add per-terminal resource controls. No duplicate placeholder parser or diacritic table.
- `terminal_element/kitty_images.rs`: existing GPUI image APIs, pane masks and z layers; deferred atlas cleanup; a replicated one-pixel border and masked affine drawing for fractional crops.
- `terminal_model/viewer_grid.rs`: strip fixed, attach-scoped resize records outside the VT parser. Local POSIX Agents viewers opt into the companion zmx advertisement. Output and authoritative VT resizing use the same lock; requested pane size remains separate from the rendered frame. Older daemons and other clients retain immediate resize.
- Initialize cell-pixel dimensions before reader startup. All TerminalViews update pixel metrics even when their cell grid is unchanged; this also affects local shells and shared browser code. Ordered daemon coordination is enabled only for local POSIX Agents/zmx.
- A safe child kill handle terminates only this viewer attach after a failed authoritative resize. It cannot signal a reused PID after the child is reaped.
- Record vendored deltas in the existing sync series and update the existing Terminal Help section.

No Zed edit, new dependency or platform-specific drawing framework is added. The companion zmx adds an optional IPC tag; existing tags, Init payload and wire generation 2 are preserved.

## Resource contract

Images are limited to 4096 per side and 4,194,304 decoded pixels each, within lib-vt's existing **10,000,000-byte source-storage budget per screen**. Images larger than that storage budget are refused; adding images can evict older retained ones. These dimension/pixel limits are upper bounds, not a promise that maximum-size RGBA assets fit. The existing storage policy is unchanged. Each TerminalView admits at most **64 MiB of padded BGRA upload buffers and 256 image generations** before allocation; unchanged visible uploads have priority and offscreen cleanup frees budget. Excess new uploads are omitted until space is available. The replicated border counts toward the limit. PNG input above 16 MiB is rejected after core buffering; source allocation is bounded before full decode. This does **not** cap total process/GPU memory or lower Ghostty's inherited 400 MiB transmission/decompression ceiling. Standalone Ghostty defaults are unchanged.

## Validation

Apple Silicon macOS is the tested runtime. The final optimized isolated full app displayed ordinary and placeholder PNGs with active search highlights, retained them through splitting and native window resizing, and restored both panes after viewer quit/relaunch without a producer redraw. A 1×1 replacement stayed solid green; the other pane's same-ID checker stayed independent. Retained history images and the scrollbar were visible. Earlier checks of unchanged painting code covered actual divider drag, selection and committed dead-key text.

The actual native TerminalModel was also exercised against disposable zmx sessions: six quiet/append/overwrite reflow cases and a pixel-only change. The legacy overwrite control drifted six columns; the coordinated viewer matched the daemon. 11,593 stream-boundary cases passed. The final optimized desktop app/helper build and current shared wasm compilation passed. The existing filtered lib-vt Kitty/C API gate passed 1,181 tests with 18 skips (46/46 steps). The subsequent full unfiltered Debug lib-vt gate passed **6,472 tests, 52 skipped**, across both roots and 46/46 steps. The earlier stopped run is historical incomplete evidence; the slow test passed on base and candidate in isolation. Earlier full web packaging predates the adapter and is not a new full web package. The companion passed 108 existing zmx tests and 39 semantic replay cases, each with 50 image-free refreshes and nested attachment.

Actual Claude Code Opus 5.5 `xhigh` reviews covered the concrete patches and corrections. Reproduced findings were independently fixed and checked; the final review's small follow-up fixes were verified afterward. A reviewer did not approve those later bytes.

The candidate is based on current Ghostex main `56a620fe83132b7e77fed81e894ab8510f80b408`, with 26 scoped files. The original runtime/core review used main `270da410`; combining with current main preserves every upstream change and the same feature additions/deletions, including the now-merged canvas fix. Local launcher/config setup, dependency symlinks, binaries, private evidence and Beads are excluded.

Current-main publication checks also passed: optimized desktop build (5m 48s), shared wasm compilation (2m 33s), scoped formatting, and exact preservation of upstream and feature added/deleted lines. The native runtime observations above predate this base update; image implementation changes are identical.

## Manual review follow-up

CodeRabbit found a native block cursor shaping placeholder glyphs and an upload cache without its own aggregate admission budget. Source VT retention was already bounded. Both failing controls were reproduced, then corrected in a three-file commit. The external production-function probe passed 15 cursor/cache checks, including exact byte/count boundaries, duplicate sharing, warm retention and offscreen recovery. Scoped formatting, optimized desktop build (5m44s) and shared wasm compilation (9.96s) passed. Actual Claude Code Opus 5.5 `xhigh` delta review found no blocking issues; final Rust bytes match its input. Later Help-only prose clarifies resource limits.

A fresh optimized isolated full Image Lab verified the actual 256-generation boundary: a 257th tiny image was omitted while full, then appeared without retransmission after two images were deleted, with the other artwork intact. A green placeholder showed a visible block cursor without a glyph overlay; focused cursor semantics are covered by the production-function probe, since OS focus was not independently established. This targeted follow-up does not repeat all earlier UI scenarios or measure GPU memory. The synthetic 64 MiB byte-boundary probe deliberately constructs frames beyond the default source-storage budget; it is a defensive cache-boundary check, not evidence that those large assets coexist in the normal app.

The [renderer CodeRabbit follow-up](https://github.com/maddada/Ghostex/pull/186#issuecomment-5967660725) completed with no new actionable comments, but skipped all three correction files as similar to previous changes. Exact corrected Rust is covered by actual Claude and local/native checks, not claimed bot approval. Its default docstring advisory (41.86%, threshold 80%) is not a required GitHub check. The companion zmx review returned no actionable comments.

## Dependency and scope

Review/land [maddada/zmx#3](https://github.com/maddada/zmx/pull/3) against **nightly**, base `feaefff987232ed4628873eb6154813ea760f284`. Then set `.dependencies/zmx` to the exact reviewed commit and repeat focused integration checks. The local renderer candidate leaves that gitlink unchanged because no upstream feature commit exists yet. Do not release this candidate as complete restoration until the pin is integrated.

Restoration covers static explicit-ID RGB/RGBA/decoded PNG assets, ordinary/virtual/mixed placements, unplaced assets, history anchors and primary state behind active alternate. Animation, relative replay, numbered/implicit IDs and pending transfers are excluded. Existing snapshot limits include inactive alternate storage, arbitrary saved cursor slots and mixed historical mode-2027 cell widths. A controlled partial-UTF-8-before-Init case also leaves an extra replacement character on both exact zmx base and candidate; it is a separate existing issue, not a claimed fix.

Native Windows wmx lacks retained graphics state; browser Kitty storage is disabled. Sixel/iTerm2 are separate protocols. Linux, Windows, Intel Mac, mixed-DPI native acceptance and CJK preedit remain unverified. LavaTUI's automatic detection still needs a separate application change; this contains no LavaTUI-specific rendering behavior.

Review head: `57a756dee3e84114f2e95d6c11ac03895b87950a` on `vespillo-tech:contrib/static-kitty-images-current`. The companion pin remains a release requirement.

## Review evidence

[Portable fixtures, probes, full validation logs and review report](https://github.com/vespillo-tech/Ghostex/blob/review/static-kitty-images/README.md). The archive includes `renderer-current-main.patch`; `renderer-candidate.patch` is the original reviewed-base patch retained for traceability.
